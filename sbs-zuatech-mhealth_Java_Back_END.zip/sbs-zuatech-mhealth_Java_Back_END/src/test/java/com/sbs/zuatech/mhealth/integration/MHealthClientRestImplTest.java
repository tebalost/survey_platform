package com.sbs.zuatech.mhealth.integration;

import com.mashape.unirest.http.HttpResponse;
import com.mashape.unirest.http.Unirest;
import com.sbs.zuatech.mhealth.integration.model.AuthorisationToken;
import com.sbs.zuatech.mhealth.util.JsonUtil;
import lombok.extern.slf4j.Slf4j;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.context.annotation.Profile;
import org.springframework.test.context.junit.jupiter.SpringExtension;

@ExtendWith(SpringExtension.class)
@SpringBootTest
@Profile({"local"})
@Slf4j
class MHealthClientRestImplTest {


    @BeforeEach
    void setUp() {


    }

    @Test
    public void should_call_Unirest(){
        try{
            Unirest.setTimeouts(0, 0);
            HttpResponse<String> response = Unirest.post("https://identity.faust.inside.cactussoft.biz/connect/token")
                    .header("Content-SurveyType", "application/x-www-form-urlencoded")
                    .field("grant_type", "client_credentials")
                    .field("client_id", "ussd")
                    .field("client_secret", "cZR5P48BVSTfSjs5KYT86DlWKzFi7Lq11q2EXECu")
                    .field("scope",
                            "ussd-api")
                    .asString();

            response.getBody();

            AuthorisationToken authorisationToken = JsonUtil.DeSerializeString(response.getBody().toString(),AuthorisationToken.class );

            log.info(authorisationToken.getAccessToken());
        } catch (Exception e){
            log.error("Could not successfully call the worker",e);

        }
    }

    @Test
    public void should_call_getToken(){
        try{
            Unirest.setTimeouts(0, 0);
            HttpResponse<String> response = Unirest.post("https://identity.faust.inside.cactussoft.biz/connect/token")
                    .header("Content-SurveyType", "application/x-www-form-urlencoded")
                    .field("grant_type", "client_credentials")
                    .field("client_id", "ussd")
                    .field("client_secret", "cZR5P48BVSTfSjs5KYT86DlWKzFi7Lq11q2EXECu")
                    .field("scope",
                            "ussd-api")
                    .asString();

            response.getBody();

            AuthorisationToken authorisationToken = JsonUtil.DeSerializeString(response.getBody().toString(),AuthorisationToken.class );

            log.info(authorisationToken.getAccessToken());
        } catch (Exception e){
            log.error("Could not successfully call the worker",e);

        }
    }

    @AfterEach
    void tearDown() {
    }
}