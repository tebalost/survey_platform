package com.sbs.zuatech.mhealth.integration;

import com.mashape.unirest.http.HttpResponse;
import com.mashape.unirest.http.Unirest;
import com.sbs.zuatech.mhealth.integration.model.AuthorisationToken;
import com.sbs.zuatech.mhealth.util.JsonUtil;
import lombok.extern.slf4j.Slf4j;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

@Slf4j
class MainTest {

    public static void main(String... arg) {

        MainTest mainTest = new MainTest();
        LocalDateTime currentDateTime = LocalDateTime.now();
//       DateTimeFormatter formatter = DateTimeFormatter.ISO_DATE_TIME;
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss");
        String dateTime = currentDateTime.format(formatter);

        should_call_getToken();

        log.info(dateTime);
    }



    public static  void should_call_getToken() {
        try {
            Unirest.setTimeouts(0, 0);
            HttpResponse<String> response = Unirest.post("https://identity.faust.inside.cactussoft.biz/connect/token")
                    .header("Content-SurveyType", "application/x-www-form-urlencoded")
                    .field("grant_type", "client_credentials")
                    .field("client_id", "ussd")
                    .field("client_secret", "cZR5P48BVSTfSjs5KYT86DlWKzFi7Lq11q2EXECu")
                    .field("scope",
                            "ussd-api")
                    .asString();

            response.getBody();

            AuthorisationToken authorisationToken = JsonUtil.DeSerializeString(response.getBody().toString(), AuthorisationToken.class);

            log.info(authorisationToken.getAccessToken());
        } catch (Exception e) {
            log.error("Could not successfully call the worker", e);

        }
    }

}
