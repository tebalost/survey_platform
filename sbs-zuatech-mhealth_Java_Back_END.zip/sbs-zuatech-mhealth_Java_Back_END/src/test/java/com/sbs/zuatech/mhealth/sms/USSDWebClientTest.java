package com.sbs.zuatech.mhealth.sms;

import lombok.extern.slf4j.Slf4j;

import java.net.URI;
import java.net.URLEncoder;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.Map;

@Slf4j
class USSDWebClientTest {

    // one instance, reuse
    private final HttpClient httpClient = HttpClient.newBuilder()
            .version(HttpClient.Version.HTTP_2)
            .build();

    public static void main(String[] args) throws Exception {

        USSDWebClientTest obj = new USSDWebClientTest();

//        System.out.println("Testing 1 - Send Http GET request");
//        obj.sendGet();

        System.out.println("Testing 2 - Send Http POST request");
        obj.sendPost();

    }

    private void sendGet() throws Exception {

        HttpRequest request = HttpRequest.newBuilder()
                .GET()
                .uri(URI.create("https://eazy-survey.africa/api/ping"))
                .setHeader("User-Agent", "Java 11 HttpClient Bot")
                .build();

        HttpResponse<String> response = httpClient.send(request, HttpResponse.BodyHandlers.ofString());

        // print status code
        System.out.println(response.statusCode());

        // print response body
        System.out.println(response.body());

    }

    private void sendPost() throws Exception {
        Map<Object, Object> data = new HashMap<>();
        // Initial
//        data.put("xml", "<ussdAppRequest>\n" +
//                "<msisdn>27837747118</msisdn>\n" +
//                "<sessionId>7247952383</sessionId>\n" +
//                "<parameter>\n" +
//                "</parameter>\n" +
//                "<type>initial</type>\n" +
//                "<network>VOD</network>\n" +
//                "<code>*120*103#</code>\n" +
//                "</ussdAppRequest>");

//       Action
//        data.put("xml", "<ussdAppRequest>\n" +
//                "   <msisdn>27837747118</msisdn>\n" +
//                "   <sessionId>4871782656464444</sessionId>\n" +
//                "   <name>NextStateAction</name>\n" +
//                "   <network>MTN</network>\n" +
//                "   <fields>\n" +
//                "      <field>\n" +
//                "         <name>userResponse</name>\n" +
//                "         <value>1</value>\n" +
//                "      </field>\n" +
//                "   </fields>\n" +
//                "   <type>action</type>\n" +
//                "</ussdAppRequest>");
//
//
//        HttpRequest request = HttpRequest.newBuilder()
//                .POST(buildFormDataFromMap(data))
//                .uri(URI.create("http://localhost:8082/api/execute-ussd"))
//                .setHeader("User-Agent", "Java 11 HttpClient Bot") // add request header
//                .header("Content-Type", "application/x-www-form-urlencoded")
//                .build();




        data.put("xml", "<ussdAppRequest>\n" +
                "   <msisdn>27837747118</msisdn>\n" +
                "   <sessionId>4871782656464444</sessionId>\n" +
                "   <name>NextStateAction</name>\n" +
                "   <network>MTN</network>\n" +
                "   <fields>\n" +
                "      <field>\n" +
                "         <name>userResponse</name>\n" +
                "         <value>1</value>\n" +
                "      </field>\n" +
                "   </fields>\n" +
                "   <type>action</type>\n" +
                "</ussdAppRequest>");


        HttpRequest request = HttpRequest.newBuilder()
                .POST(buildFormDataFromMap(data))
                .uri(URI.create("http://localhost:8082/api/execute-ussd"))
                .setHeader("User-Agent", "Java 11 HttpClient Bot") // add request header
                .header("Content-Type", "application/x-www-form-urlencoded")
                .build();


        HttpResponse<String> response = httpClient.send(request, HttpResponse.BodyHandlers.ofString());


        // print status code
        System.out.println("response.statusCode() ->   " +response.statusCode());

        // print response body
        System.out.println("response.body() --> "+response.body().toString());

    }

    private static HttpRequest.BodyPublisher buildFormDataFromMap(Map<Object, Object> data) {
        var builder = new StringBuilder();
        for (Map.Entry<Object, Object> entry : data.entrySet()) {
            if (builder.length() > 0) {
                builder.append("&");
            }
            builder.append(URLEncoder.encode(entry.getKey().toString(), StandardCharsets.UTF_8));
            builder.append("=");
            builder.append(URLEncoder.encode(entry.getValue().toString(), StandardCharsets.UTF_8));
        }
        System.out.println(builder.toString());
        return HttpRequest.BodyPublishers.ofString(builder.toString());
    }



}