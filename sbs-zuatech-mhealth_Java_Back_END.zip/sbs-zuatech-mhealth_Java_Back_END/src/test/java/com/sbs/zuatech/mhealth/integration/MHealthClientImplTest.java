
package com.sbs.zuatech.mhealth.integration;

import com.sbs.zuatech.mhealth.api.dto.menu.SurveyAnswer;
import com.sbs.zuatech.mhealth.api.dto.menu.SurveyMenu;
import com.sbs.zuatech.mhealth.api.dto.webhook.WebHookSurveyRequest;
import com.sbs.zuatech.mhealth.exception.MHealthSurveyCallFailed;
import com.sbs.zuatech.mhealth.integration.model.SurveyParticipant;
import com.sbs.zuatech.mhealth.util.JsonUtil;
import lombok.extern.slf4j.Slf4j;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.context.annotation.Profile;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.util.Assert;

import java.util.ArrayList;
import java.util.List;

@ExtendWith(SpringExtension.class)
@SpringBootTest
@Profile({"local"})
@Slf4j
class MHealthClientImplTest {

    @Autowired
    private MHealthClientImpl mHealthClient;

    @Test
    public void should_find_correct_participants_when_it_is_called(){

        final String givenSurveyId = "603f4e6b636ed91cac7b958a"; // created for test
        List<SurveyParticipant> expectedSurveyParticipants  = new ArrayList<>();

        Assert.isTrue(expectedSurveyParticipants.isEmpty(), "Here the array is still empty");
        expectedSurveyParticipants = mHealthClient.findSurveyParticipants(givenSurveyId);
        Assert.isTrue(!expectedSurveyParticipants.isEmpty(), "Here the array should not be empty");
    }

    @Test
    public void should_find_correct_questions_when_it_is_called() throws MHealthSurveyCallFailed {

        final String givenSurveyId = "603f4e6b636ed91cac7b958a"; // created for test

        final String givenUserId = "603f5013e35da649d3bc274a";
        SurveyMenu expectedSurveySurveyMenu = new SurveyMenu();

        Assert.isTrue(expectedSurveySurveyMenu.getAnswers().isEmpty(), "Should  be empty");
        expectedSurveySurveyMenu = mHealthClient.findSurveyFirstMenu(givenSurveyId, givenUserId);
        Assert.isTrue(!expectedSurveySurveyMenu.getAnswers().isEmpty(), "Should not be empty");
    }

    @Test
    public void should_submit_answer_correctly() throws MHealthSurveyCallFailed {

        final String givenSurveyId = "603f4e6b636ed91cac7b958a"; // created for test
        final String givenUserId = "603f5013e35da649d3bc274a";
        final String questionId = "e6e51458-cd9a-46fd-8b59-559c7ebc2f4f";
        final String answerId = "cf4d4f9f-4c14-4d1f-88c7-b6e2f9d9ac59";

         List<SurveyAnswer.Answer> answers = new ArrayList<>();
        answers.add(SurveyAnswer.Answer.builder()
                .answerId("cf4d4f9f-4c14-4d1f-88c7-b6e2f9d9ac59")
                .build());


     mHealthClient.submitSurveyAnswer(givenSurveyId, givenUserId,questionId, SurveyAnswer.builder()
             .answers(answers)
             .build());
    }


    @Test
    public void date_json_desirialisation(){

        try {

            String stringRequestXML = "{\"Id\":\"60426558636ed91cac7b9590\",\"Name\":\"Survey For SBS test\",\"Finish\":\"2021-03-09T15:05:00Z\"}";
            WebHookSurveyRequest backToObjectFromFE = JsonUtil.DeSerializeString(stringRequestXML, WebHookSurveyRequest.class);


//            WebHookRequest webHookRequest = new WebHookRequest();
//
//            webHookRequest.setSurveyClosure(new Date());
//            webHookRequest.setSurveyName("Test Time");
//            webHookRequest.setSurveyId("wqewrewrwerwqewq");
//
//            String stringRequest = JsonUtil.serializeObject(webHookRequest);

//            WebHookRequest backToObject = JsonUtil.DeSerializeString(stringRequest, WebHookRequest.class);
        } catch (Exception e){
            e.printStackTrace();
        }
    }

}
