package com.sbs.zuatech.mhealth.persistance.repository;

import com.sbs.zuatech.mhealth.persistance.entity.MessageStatus;
import com.sbs.zuatech.mhealth.persistance.entity.SurveyCache;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.context.annotation.Profile;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.util.Assert;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.stream.StreamSupport;

@ExtendWith(SpringExtension.class)
@SpringBootTest
@Profile("local")
class SurveyCacheRepositoryTest {
    @Autowired
    private SurveyCacheRepository repository;

    @Test
    public void saveInitialData() throws Exception {
        List<SurveyCache> surveyCacheList = new ArrayList<>();
        final Date finishDate = new Date();
        for (var i = 0; i < 4; i++) {
            surveyCacheList.add(SurveyCache.builder()
                    .surveyId("BHGGD86urt-kd")
                    .surveyName("TEST")
//                    .finishDate(LocalDateTime.now())
                    .msisdn("2784574543" + i)
                    .surveyUserId("45498948584-454958" + i)
                    .messageStatus(MessageStatus.DISPATCHED)
                    .build());
        }


        Iterable<SurveyCache> dbSurveyCaches = repository.findAll();
        Assert.isTrue(StreamSupport.stream(dbSurveyCaches.spliterator(), false).count() == 0, "The list from the database should be 0");
        repository.saveAll(surveyCacheList);
        Assert.isTrue(StreamSupport.stream(dbSurveyCaches.spliterator(), false).count() == 0, "The list from the database should be 0");
    }
}
