package com.sbs.zuatech.mhealth.api.dto.menu;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.ArrayList;
import java.util.List;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
@JsonPropertyOrder({
        "id",
        "value",
        "pictureUris",
        "order",
        "isRequired",
        "questionType",
        "answers"
})
public class SurveyMenu {

    @JsonProperty("id")
    private String questionId;
    @JsonProperty("value")
    private String value;
    @JsonProperty("pictureUris")
    @JsonIgnore
    private List<Object> pictureUris = new ArrayList<Object>();
    @JsonProperty("order")
    private Integer order;
    @JsonIgnore
    @JsonProperty("isRequired")
    private Boolean isRequired;
    @JsonProperty("questionType")
    private Integer questionType;
    @JsonProperty("answers")
    private List<Answer> answers = new ArrayList<Answer>();

    @JsonInclude(JsonInclude.Include.NON_NULL)
    @JsonPropertyOrder({
            "id",
            "order",
            "value",
            "isUserAnswer",
            "answerType",
            "pictureUris"
    })
    @Data
    @Builder
    @AllArgsConstructor
    @NoArgsConstructor
    public static class Answer {

        @JsonProperty("id")
        private String answerId;
        @JsonProperty("order")
        private Integer order;
        @JsonProperty("value")
        private String value;
        @JsonProperty("isUserAnswer")
        private boolean userAnswer;
        @JsonProperty("answerType")
        private Integer answerType;
        @JsonProperty("pictureUris")
        @JsonIgnore
        private List<Object> pictureUris = new ArrayList<>();
    }
}


