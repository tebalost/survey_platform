package com.sbs.zuatech.mhealth.service;

import com.sbs.zuatech.mhealth.exception.InvalidInput;
import com.sbs.zuatech.mhealth.exception.RecordNotFoundInDataBase;
import com.sbs.zuatech.mhealth.persistance.entity.BusinessUser;
import com.sbs.zuatech.mhealth.persistance.repository.BusinessUserRepository;
import com.sbs.zuatech.mhealth.persistance.repository.SystemClientRepository;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

@Service
@Slf4j
public class BusinessUserServiceImpl implements BusinessUserService {

    private final SystemClientRepository systemClientRepository;

    private final BusinessUserRepository businessUserRepository;

    @Autowired
    public BusinessUserServiceImpl(SystemClientRepository systemClientRepository,
                                   BusinessUserRepository businessUserRepository) {
        this.systemClientRepository = systemClientRepository;
        this.businessUserRepository = businessUserRepository;
    }

    @Override
    public BusinessUser createUpdateUser(BusinessUser businessUser) throws InvalidInput, RecordNotFoundInDataBase {
        if (!StringUtils.hasLength(businessUser.getAuthorityCode())
                    || !systemClientRepository.findByCode(businessUser.getAuthorityCode()).isPresent()) {
                log.error("Failed user validation, user is not valid");
                throw new InvalidInput("The user must have a valid Authority body organisation");
        }
        try {
            return businessUserRepository.save(businessUser);
        } catch (Exception e) {
            log.error("failed to add the user in the db -> ", e);
             throw new RecordNotFoundInDataBase("The user must have a valid Authority body organisation");
        }
    }

    @Override
    public Iterable<BusinessUser> findAll() throws InvalidInput, RecordNotFoundInDataBase {
        try{
              return businessUserRepository.findAll();
        }  catch ( Exception e){
            throw new RecordNotFoundInDataBase("Not able to find the records in the DB");
        }
    }

    @Override
    public Iterable<BusinessUser> findBySystemClient(String systemClientCode) throws InvalidInput,
            RecordNotFoundInDataBase {
        if(StringUtils.hasLength(systemClientCode))
            throw new InvalidInput("Invalid Authorisation code entered");
        try{
            return businessUserRepository.findAllByAuthorityCode(systemClientCode);

        } catch (Exception e){
            throw new RecordNotFoundInDataBase("Not able to find the records in the DB");
        }
    }

    @Override
    public BusinessUser findByEmail(String email) throws InvalidInput, RecordNotFoundInDataBase {
        if (!StringUtils.hasLength(email))
            throw new InvalidInput("User needs to have a valid email address");
        BusinessUser businessUser = businessUserRepository.findFirstByEmail(email).orElseThrow(()
                -> new RecordNotFoundInDataBase("User not registered as yet"));
        if (businessUser.getUserStatus()!= BusinessUser.UserStatus.ACTIVE)
            throw new InvalidInput("User is not Active ");
        return businessUser;
    }
}
