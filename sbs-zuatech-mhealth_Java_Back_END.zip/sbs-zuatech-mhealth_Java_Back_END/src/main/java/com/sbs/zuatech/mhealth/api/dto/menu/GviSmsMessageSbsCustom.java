package com.sbs.zuatech.mhealth.api.dto.menu;


import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.xml.bind.annotation.XmlRootElement;
import java.util.ArrayList;
import java.util.List;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@XmlRootElement(name = "gviSmsMessage")
public class GviSmsMessageSbsCustom {
    RecipientList recipientList;
    TransmissionRules transmissionRules;
    private String affiliateCode;
    private String authenticationCode;
    private String submitDateTime;
    private String messageType;

    @Data
    @Builder
    @NoArgsConstructor
    @AllArgsConstructor
    public static class RecipientList {
        List<Recipient> recipient = new ArrayList<>();
        private String message;

        @Data
        @Builder
        @NoArgsConstructor
        @AllArgsConstructor
        public static class Recipient {
            private String msisdn;
            private String message;
        }
    }


    @Data
    @Builder
    @NoArgsConstructor
    @AllArgsConstructor
    public static class TransmissionRules {
        TransmitPeriod transmitPeriod;
        private String transmitDateTime;

        @Data
        @Builder
        @NoArgsConstructor
        @AllArgsConstructor
        public static class TransmitPeriod {
            private String startHour;
            private String endHour;
        }

    }

}
