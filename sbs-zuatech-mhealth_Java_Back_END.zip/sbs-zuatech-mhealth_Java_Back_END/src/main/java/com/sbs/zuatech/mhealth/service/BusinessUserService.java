package com.sbs.zuatech.mhealth.service;

import com.sbs.zuatech.mhealth.exception.InvalidInput;
import com.sbs.zuatech.mhealth.exception.RecordNotFoundInDataBase;
import com.sbs.zuatech.mhealth.persistance.entity.BusinessUser;

public interface BusinessUserService {

    BusinessUser createUpdateUser(final BusinessUser businessUser) throws InvalidInput, RecordNotFoundInDataBase;

    Iterable<BusinessUser> findAll() throws InvalidInput, RecordNotFoundInDataBase;

    Iterable<BusinessUser> findBySystemClient(final String systemClientCode) throws InvalidInput, RecordNotFoundInDataBase;

    BusinessUser findByEmail(final String email) throws InvalidInput, RecordNotFoundInDataBase;
}
