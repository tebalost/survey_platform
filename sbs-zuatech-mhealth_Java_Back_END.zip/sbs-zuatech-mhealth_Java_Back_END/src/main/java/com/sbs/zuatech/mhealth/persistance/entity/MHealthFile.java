package com.sbs.zuatech.mhealth.persistance.entity;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.*;

import javax.persistence.*;

@Entity
@Table
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class MHealthFile {

    @JsonInclude(JsonInclude.Include.NON_EMPTY)
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Setter(AccessLevel.NONE)
    private long mHealthFileId;

    @JsonProperty(value = "MSISDN_PARTICIPANT")
    @Column(name = "msisdn_participant")
    private String msisdn;

    @JsonProperty(value = "TYPE_ID")
    @Column(name = "type_id")
    private String typeId;

    @JsonProperty(value = "TYPE_CODE")
    @Column(name = "type_name")
    private String typeName;

    @JsonProperty(value = "TYPE_NAME")
    @Column(name = "type_code")
    private String typeCode;

    @JsonProperty(value = "AUTHORITY")
    @Column(name = "authority")
    private String authority;

    @JsonProperty(value = "COUNTRY")
    @Column(name = "country")
    private String country;
}
