package com.sbs.zuatech.mhealth.api.dto.webhook;

import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.*;

import java.util.Date;

@NoArgsConstructor
@AllArgsConstructor
@Builder
@ToString
@Data
public class TempCustomer {
    Integer id;
    String name;
    Country country;
    String company;
    Date date;
    String status;
    String activity;
    Representative representative;
    Boolean verified;
    Boolean balance;

    @NoArgsConstructor
    @AllArgsConstructor
    @Builder
    @ToString
    @Data
    public static class Country {
        String name;
        String code;
    }

    @NoArgsConstructor
    @AllArgsConstructor
    @Builder
    @ToString
    @Data
    public static class Representative {
        String name;
        String image;
    }
}
