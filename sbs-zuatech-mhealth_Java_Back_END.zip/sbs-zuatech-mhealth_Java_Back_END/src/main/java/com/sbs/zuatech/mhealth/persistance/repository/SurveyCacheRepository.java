package com.sbs.zuatech.mhealth.persistance.repository;

import com.sbs.zuatech.mhealth.persistance.entity.MessageStatus;
import com.sbs.zuatech.mhealth.persistance.entity.SurveyCache;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import javax.transaction.Transactional;
import java.util.List;
import java.util.Optional;

@Repository
public interface SurveyCacheRepository extends CrudRepository<SurveyCache, Long> {

    /**
     *
     * @param surveyId
     * @param msisdn
     * @param messageStatus
     * @return
     */
    Optional<SurveyCache> findBySurveyIdAndMsisdnAndMessageStatus(String surveyId, String msisdn, MessageStatus messageStatus);

    /**
     *
     * @param msisdn
     * @param messageStatus
     * @return
     */
    Optional<SurveyCache> findFirstByMsisdnAndMessageStatus(String msisdn, MessageStatus messageStatus);

    /**
     *
     * @param msisdn
     * @param messageStatus
     * @return
     */
    Iterable<SurveyCache> findAllByMsisdnAndMessageStatus(String msisdn, MessageStatus messageStatus);

    int countAllByAuthorityCode (final String authorityCode);

    @Transactional
    @Query(value = "select survey_id, survey_name from survey_cache group by survey_id,survey_name", nativeQuery = true)
    List<Object[]> allUniqueSurveys();

    @Transactional
    @Query(value = "select survey_id, survey_name from survey_cache where authority_code = ?1 group by survey_id,survey_name", nativeQuery = true)
    List<Object[]> allAuthorityUniqueSurveys(String authorityCode);

    int countAllByMessageStatusAndSurveyId(final  MessageStatus messageStatus,String surveyId);

    int countAllByMessageStatusAndSurveyIdAndAuthorityCode(final  MessageStatus messageStatus, final String surveyId, final String authorityCode);
}
