package com.sbs.zuatech.mhealth.api.dto.reports;

import lombok.*;

@NoArgsConstructor
@AllArgsConstructor
@Builder
@ToString
@Data
public class DashboardTopMenuStats {
    private long totalActiveSurveys;
    private long totalActiveAdherences;
    private long totalSentSMS;
    private long totalUssdMessages;
}
