package com.sbs.zuatech.mhealth.persistance.entity;

public enum MessageStatus {
    DISPATCHED, INCOMPLETE, COMPLETED, ABORTED, ERROR, DELIVERED
}
