package com.sbs.zuatech.mhealth.api.resources;

import com.sbs.zuatech.mhealth.api.dto.reports.DashboardTopMenuStats;
import com.sbs.zuatech.mhealth.api.dto.reports.TypeStats;
import com.sbs.zuatech.mhealth.exception.InvalidInput;
import com.sbs.zuatech.mhealth.exception.RecordNotFoundInDataBase;
import com.sbs.zuatech.mhealth.service.BusinessUserService;
import com.sbs.zuatech.mhealth.service.ReportService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import reactor.core.publisher.Mono;

import java.util.List;

@RestController
@RequestMapping(path = "/api")
@Data
@Slf4j
public class ReportsResource {
    final private BusinessUserService businessUserService;
    final private ReportService reportService;

    @Autowired
    public ReportsResource(BusinessUserService businessUserService, ReportService reportService) {
        this.businessUserService = businessUserService;
        this.reportService = reportService;
    }

    @GetMapping(path = "dashboard-top-menu-stats/{authority-code}/role/{role-code}")
    @Operation(summary = "dashboard-top-menu-stats", tags = "Reports")
    public Mono<ResponseEntity<DashboardTopMenuStats>> getDashboardTopMenuStats(
            @Parameter(description = " The Authority Code of the User. Cannot be empty.",
                    required = true)
            @PathVariable("authority-code") String authorityCode,
            @Parameter(description = " The Role Code of the User. Cannot be empty.",
                    required = true)
            @PathVariable("role-code") String roleCode
    ) throws InvalidInput, RecordNotFoundInDataBase {
        return Mono.just(ResponseEntity.ok()
                .body(reportService.getMenuStats(authorityCode, roleCode)));
    }

    @GetMapping(path = "surveys-states/{authority-code}/role/{role-code}")
    @Operation(summary = "surveys-states", tags = "Reports")
    public Mono<ResponseEntity<List<TypeStats>>> getSurveyStates(
            @Parameter(description = " The Authority Code of the User. Cannot be empty.",
                    required = true)
            @PathVariable("authority-code") String authorityCode,
            @Parameter(description = " The Role Code of the User. Cannot be empty.",
                    required = true)
            @PathVariable("role-code") String roleCode )
            throws InvalidInput, RecordNotFoundInDataBase {
        return Mono.just(ResponseEntity.ok()
                .body(reportService.getSurveyStates(authorityCode, roleCode)));
    }

    @GetMapping(path = "adherence-states/{authority-code}/role/{role-code}")
    @Operation(summary = "adherence-states", tags = "Reports")
    public Mono<ResponseEntity<List<TypeStats>>> getAdherenceStates(
            @Parameter(description = " The Authority Code of the User. Cannot be empty.",
                    required = true)
            @PathVariable("authority-code") String authorityCode,
            @Parameter(description = " The Role Code of the User. Cannot be empty.",
                    required = true)
            @PathVariable("role-code") String roleCode
    )
            throws InvalidInput, RecordNotFoundInDataBase {
        return Mono.just(ResponseEntity.ok()
                .body(reportService.getAdherenceStates(authorityCode, roleCode)));
    }

}


