package com.sbs.zuatech.mhealth.api.resources;

import com.sbs.zuatech.mhealth.api.dto.ResponseMessage;
import com.sbs.zuatech.mhealth.exception.InvalidInput;
import com.sbs.zuatech.mhealth.persistance.entity.MHealthFile;
import com.sbs.zuatech.mhealth.persistance.entity.USSDSessionReport;
import com.sbs.zuatech.mhealth.service.ExcelService;
import com.sbs.zuatech.mhealth.util.ExcelHelper;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.util.List;

@RestController
@RequestMapping(path = "/api")
@Data
@Slf4j
public class ExcelController {
    @Autowired
    ExcelService fileService;


    @PostMapping("/uploadFile")
    public void uploadFile(@RequestParam("file") MultipartFile file,
                           @RequestParam("userId") Integer UserId,
                           @RequestParam("docType") String docType) {

        log.info("Testing file {}", file);

    }

    @PostMapping(value = "/excel-file-upload")
//    @ApiOperation(value = "excel-file-upload", tags = "Participant Reports")
    public ResponseEntity<ResponseMessage> uploadFile(@RequestParam("file") MultipartFile file) {
        String message = "";

        log.info("Multipart file -> {}", file);
        if (ExcelHelper.hasExcelFormat(file)) {
            try {
                fileService.save(file);

                message = "Uploaded the file successfully: " + file.getOriginalFilename();
                return ResponseEntity.status(HttpStatus.OK).body(new ResponseMessage(message));
            } catch (Exception e) {
                message = "Could not upload the file: " + file.getOriginalFilename() + "!";
                return ResponseEntity.status(HttpStatus.EXPECTATION_FAILED).body(new ResponseMessage(message));
            }
        }
        message = "Please upload an excel file!";
        return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(new ResponseMessage(message));
    }

    @PostMapping(value = "/upload-mHealth-file")
//    @ApiOperation(value = "upload-mHealth-file", tags = "Participant Reports")
    public ResponseEntity<ResponseMessage> uploadMHealthFile(@RequestBody List<MHealthFile> request) throws InvalidInput {
        String message = "";
        log.debug("MHealth files  -> {}", request);

        try {
            fileService.saveAllMheatlFiles(request);

            message = "Uploaded the file successfully !";
            return ResponseEntity.status(HttpStatus.OK).body(new ResponseMessage(message));
        } catch (Exception e) {
            message = "Could not upload the file !";
            return ResponseEntity.status(HttpStatus.EXPECTATION_FAILED).body(new ResponseMessage(message));
        }
    }

    @PostMapping(value = "/upload-ussd-session-report")
//    @ApiOperation(value = "upload-ussd-session-report", tags = "Participant Reports")
    public ResponseEntity<ResponseMessage> uploadUssdSessionReport(@RequestBody List<USSDSessionReport> request) throws InvalidInput {
        String message = "";
        log.debug("MHealth files  -> {}", request);


        try {
            fileService.saveUSSDSessionReport(request);

            message = "Uploaded the file successfully !";
            return ResponseEntity.status(HttpStatus.OK).body(new ResponseMessage(message));
        } catch (Exception e) {
            message = "Could not upload the file !";
            return ResponseEntity.status(HttpStatus.EXPECTATION_FAILED).body(new ResponseMessage(message));
        }
    }
}
