package com.sbs.zuatech.mhealth.persistance.entity;

import lombok.*;

import javax.persistence.*;
import java.util.Date;

@Entity
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class SurveyCache {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Setter(AccessLevel.NONE)
    private long surveyCacheId;
    private String surveyId;
    private String surveyName;
    private String finishDate;
    private String surveyUserId;
    private String authorityCode;
    private String msisdn;
    private String answer;
    private String answerId;
    private String question;
    private String questionId;
    private String network;
    private String surveyTakenQuestionId;
    @Enumerated(EnumType.STRING)
    private MessageStatus messageStatus;
    @Column(name = "SURVEY_PAYLOAD", length = 1024)
    private String surveyPayloadJson;
    @Column(name = "USSD_PAYLOAD", length = 1024)
    private String ussdPayloadXml;
    @Temporal(TemporalType.TIMESTAMP)
    @Setter(AccessLevel.NONE)
    private Date createdAt;
    @Temporal(TemporalType.TIMESTAMP)
    @Setter(AccessLevel.NONE)
    private Date updatedAt;

    @Transient
    private SurveyCacheHistory surveyCacheHistory;

    @PrePersist
    public void updateDates() {
        this.createdAt = new Date();
        this.updatedAt = new Date();

        updateHistory();
    }

    @PreUpdate
    public void updatedDate() {
        this.updatedAt = new Date();
        updateHistory();
    }

    @PostUpdate
    public void processPostUpdate() {
        this.surveyCacheHistory.setSurveyCacheId(this.surveyCacheId);
    }

    @PostPersist
    public void processPostPersist() {
        this.surveyCacheHistory.setSurveyCacheId(this.surveyCacheId);
    }

    private void updateHistory() {
        this.surveyCacheHistory = new SurveyCacheHistory();
        this.surveyCacheHistory.setCreatedAt(this.getCreatedAt());
        this.surveyCacheHistory.setFinishDate(this.getFinishDate());
        this.surveyCacheHistory.setMsisdn(this.getMsisdn());
        this.surveyCacheHistory.setSurveyId(this.surveyId);
        this.surveyCacheHistory.setSurveyName(this.surveyName);
        this.surveyCacheHistory.setSurveyPayloadJson(this.surveyPayloadJson);
        this.surveyCacheHistory.setSurveyTakenQuestionId(this.surveyTakenQuestionId);
        this.surveyCacheHistory.setSurveyUserId(this.surveyUserId);
        this.surveyCacheHistory.setMessageStatus(this.messageStatus);
        this.surveyCacheHistory.setUssdPayloadXml(this.ussdPayloadXml);
        this.surveyCacheHistory.setUpdatedAt(this.updatedAt);
        this.surveyCacheHistory.setAuthorityCode(this.authorityCode);
        this.surveyCacheHistory.setNetwork(this.network);
        this.surveyCacheHistory.setAnswer(this.answer);
        this.surveyCacheHistory.setQuestion(this.question);
        this.surveyCacheHistory.setQuestionId(this.questionId);
        this.surveyCacheHistory.setAnswerId(this.answerId);
    }
}
