package com.sbs.zuatech.mhealth.service;

import com.sbs.zuatech.mhealth.api.dto.USSDAppResponse;
import com.sbs.zuatech.mhealth.exception.InvalidInput;

public interface USSDService<T extends USSDAppResponse> {

    T processSurveyNotification(String xmlInstruction) throws InvalidInput;

    String processSurveyNotificationMarshalled(String xmlInstruction) throws InvalidInput;

    String processAdherentNotification(String xmlInstruction) throws InvalidInput;

}
