package com.sbs.zuatech.mhealth.persistance.repository;

import com.sbs.zuatech.mhealth.persistance.entity.BusinessUser;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface BusinessUserRepository extends CrudRepository<BusinessUser, Long> {
    Optional<BusinessUser> findFirstByEmail(final String email);

    Iterable<BusinessUser> findAllByAuthorityCode(String authorityCode);
}
