package com.sbs.zuatech.mhealth.exception;

import org.springframework.web.bind.annotation.ResponseStatus;

@ResponseStatus()
public class RecordNotFoundInDataBase extends Exception {


    public RecordNotFoundInDataBase() {
        super();
    }


    public RecordNotFoundInDataBase(String message) {
        super(message);
    }

}
