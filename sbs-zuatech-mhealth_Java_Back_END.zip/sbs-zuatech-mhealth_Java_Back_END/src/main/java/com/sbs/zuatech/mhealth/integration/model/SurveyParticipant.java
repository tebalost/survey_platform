package com.sbs.zuatech.mhealth.integration.model;

import lombok.*;
import lombok.experimental.SuperBuilder;

@Data
@AllArgsConstructor
@NoArgsConstructor
@SuperBuilder
@Builder
@ToString(doNotUseGetters = true)
public class SurveyParticipant {
    String id;
    String phone;
}
