package com.sbs.zuatech.mhealth.persistance.entity;

public enum SurveyType {
    SURVEY, ADHERENCE
}
