package com.sbs.zuatech.mhealth.cache;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;
import java.util.Objects;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class USSDCacheDto {
    String surveyId;
    String surveyName;
    LocalDate finish;

    String userId;
    String msisdn;

    String questionId;
    String answer;

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        USSDCacheDto that = (USSDCacheDto) o;
        return surveyId.equals(that.surveyId) &&
                userId.equals(that.userId) &&
                questionId.equals(that.questionId);
    }

    @Override
    public int hashCode() {
        return Objects.hash(surveyId, userId, questionId);
    }
}
