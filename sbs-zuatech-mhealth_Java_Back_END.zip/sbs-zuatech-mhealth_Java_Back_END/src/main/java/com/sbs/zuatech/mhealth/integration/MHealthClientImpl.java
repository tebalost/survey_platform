package com.sbs.zuatech.mhealth.integration;

import com.fasterxml.jackson.core.type.TypeReference;
import com.mashape.unirest.http.HttpResponse;
import com.mashape.unirest.http.Unirest;
import com.sbs.zuatech.mhealth.api.dto.menu.SurveyAnswer;
import com.sbs.zuatech.mhealth.api.dto.menu.SurveyMenu;
import com.sbs.zuatech.mhealth.config.properties.MHealthProperties;
import com.sbs.zuatech.mhealth.exception.MHealthSurveyCallFailed;
import com.sbs.zuatech.mhealth.integration.model.AuthorisationToken;
import com.sbs.zuatech.mhealth.integration.model.SurveyParticipant;
import com.sbs.zuatech.mhealth.util.JsonUtil;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Slf4j
@Component
public class MHealthClientImpl implements MHealthClient {

    final private MHealthProperties properties;

    @Autowired
    public MHealthClientImpl(MHealthProperties properties) {
        this.properties = properties;
    }

    public List<SurveyParticipant> findSurveyParticipants(final String surveyId) {
        try {
            final String uri = String.format("/feature-phones/%s/users", surveyId);
            HttpResponse<String> response = Unirest.get(properties.getUrlSurvey() + uri)
                    .headers(getHeaders())
                    .asString();
            return JsonUtil.DeSerializeObjectList(response.getBody(), new TypeReference<List<SurveyParticipant>>() {
            });
        } catch (Exception e) {
            log.error("Call to get survey participants not successful {}", e.getLocalizedMessage());
            return null;
        }
    }

    @Override
    public SurveyMenu findSurveyFirstMenu(String surveyId, String userId) throws MHealthSurveyCallFailed {
        final String uri = String.format("%s%s/questions/first?userId=%s", FEATURE_PHONE_URI, surveyId, userId);
        log.info("First Menu URI =>    \n\t{}\nt", uri);
        return getSurveyMenu(uri);
    }

    @Override
    public boolean submitSurveyAnswer(String surveyId, String userId, String questionId, SurveyAnswer surveyAnswer)
            throws MHealthSurveyCallFailed {
        final String uri = FEATURE_PHONE_URI + surveyId + "/questions/" + questionId + "/answer?userId=" + userId;
        Map<String, String> headersMap = getHeaders();
        headersMap.put("Content-Type", "application/json");
        try {
            String userAnswer = JsonUtil.serializeObject(surveyAnswer);
            log.info("Answer to submit =========     >>> \n{}\n", userAnswer);

            HttpResponse<String> response = Unirest.post(properties.getUrlSurvey() + uri)
                    .headers(headersMap)
                    .body(userAnswer)
                    .asString();
            return response.getStatus() == 200;
        } catch (Exception e) {
            log.error("Call to get survey question not successful {}", e.getMessage());

        }
        return false;
    }

    @Override
    public SurveyMenu findSurveyNextMenu(String surveyId, String userId, String questionId) throws MHealthSurveyCallFailed {
        final String uri = String.format("%s%s/questions/%s/next?userId=%s", FEATURE_PHONE_URI, surveyId, questionId, userId);

        log.info("Next Menu URI =>    \n\t{}\nt", uri);
        return getSurveyMenu(uri);
    }

    @Override
    public void patchSurvey(String surveyId, String userId) {
        final String uri = FEATURE_PHONE_URI + surveyId + "?userId=" + userId;
        try {
            HttpResponse<String> response = Unirest.patch(properties.getUrlSurvey() + uri)
                    .headers(getHeaders())
                    .asString();

            log.info("Survey is Patched \n{}\n", response);
        } catch (Exception e) {
            log.error("Call to get survey question not successful {}", e.getMessage());

        }

    }

    @Override
    public void patchProfileAdherence(String adherenceId, String body, int type) throws MHealthSurveyCallFailed {
        //TODO check the type and call the relevant URL
        StringBuilder uri = new StringBuilder(FEATURE_PHONE_URI + adherenceId);

        if(type==0) {
            uri.append("/treatment");
        }
        else if(type == 1){
            uri.append("/symptom");
        }
        else if(type == 2){
            uri.append("/mental");
        }
        log.info(">>>>>>>>> the PATCH URI is -> {}", uri);
        Map<String, String> headersMap = getHeaders();
        headersMap.put("Content-Type", "application/json");
        try{
           log.info("Patching the adherence  URL {} , and body  {}",uri.toString(), body);
            HttpResponse<String> response = Unirest.patch(properties.getUrlProfile() + uri.toString())
                    .headers(headersMap)
                    .body(body)
                    .asString();
         log.info("Adherence Patch Response  {} ",response.getBody());
        }catch (Exception e){
            log.error("Call to get survey question not successful {}", e.getMessage());
        }
    }


    private SurveyMenu getSurveyMenu(String uri) {
        try {
            HttpResponse<String> response = Unirest.get(properties.getUrlSurvey() + uri)
                    .headers(getHeaders())
                    .asString();

            if (response.getStatus() == 200) {
                return JsonUtil.DeSerializeString(response.getBody(), SurveyMenu.class);
            }
            log.info( "Call to get survey question returned status {} ---- for the URI - {} \n body > {}", response.getStatus(), uri,response.getBody() );
        } catch (Exception e) {
            log.error("Call to get survey question not successful {}", e.getMessage());
        }
        return null;
    }

    private String getAuthorisationToken() {
        //FIXME Cache the token later
        final String tokenUri = "/connect/token";
        final String okResultString = "OK";

        try {
            Unirest.setTimeouts(0, 0);
            HttpResponse<String> response = Unirest.post(String.format("%s%s", properties.getUrlIdentity(), tokenUri))
                    .header("Content-SurveyType", "application/x-www-form-urlencoded")
                    .field("grant_type", properties.getGrantType())
                    .field("client_id", properties.getClientId())
                    .field("client_secret", properties.getClientSecret())
                    .field("scope", properties.getScope())
                    .asString();

            log.info( "Call to Authorise  {}  \n body > {}", response.getStatus(),response.getBody() );

            if (StringUtils.hasLength(response.getStatusText())
                    && response.getStatusText().equals(okResultString))
                return JsonUtil.DeSerializeString(response.getBody(), AuthorisationToken.class).getAccessToken();
        } catch (Exception e) {
            log.error("Could not successfully call the worker", e);

        }
        return null;
    }

    private Map getHeaders() {
        //FIXME label expiry of the token
        // NOTES this taken is not renewable
        final String token = getAuthorisationToken();
        Map<String, String> headersMap = new HashMap<>();
        headersMap.put("accept", "*/*");
        headersMap.put("Authorization", "Bearer " + token);

        return headersMap;
    }
}
