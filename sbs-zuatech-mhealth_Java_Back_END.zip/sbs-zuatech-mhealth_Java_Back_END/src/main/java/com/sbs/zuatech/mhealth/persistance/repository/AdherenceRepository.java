package com.sbs.zuatech.mhealth.persistance.repository;

import com.sbs.zuatech.mhealth.persistance.entity.Adherence;
import com.sbs.zuatech.mhealth.persistance.entity.MessageStatus;
import com.sbs.zuatech.mhealth.persistance.entity.SurveyCacheHistory;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Slice;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.PagingAndSortingRepository;
import org.springframework.stereotype.Repository;

import javax.transaction.Transactional;
import java.util.List;
import java.util.Optional;

@Repository
public interface AdherenceRepository extends PagingAndSortingRepository<Adherence, Long> {

    Optional<Adherence> findByMsisdnAndMessageStatus(String msisdn, MessageStatus messageStatus);

    Iterable<Adherence> findAllByMsisdnAndMessageStatusNotOrderByAdherenceIdDesc(String msisdn, MessageStatus messageStatus);

    Iterable<Adherence> findAllByAuthorityCode(String authorityCode);

    Slice<Adherence> findAllByAuthorityCode(String authorityCode, Pageable pageable);

    int countAllByAuthorityCode(final String authorityCode);


    @Transactional
    @Query(value = "select count(correlation_id), correlation_id from adherence group by correlation_id", nativeQuery = true)
    List<Object[]> allUniqueAdherence();

    @Transactional
    @Query(value = "select count(correlation_id), correlation_id from  adherence where authority_code =?1 group by correlation_id", nativeQuery = true)
    List<Object[]> allAuthorityAdherence(String authorityCode);
}
