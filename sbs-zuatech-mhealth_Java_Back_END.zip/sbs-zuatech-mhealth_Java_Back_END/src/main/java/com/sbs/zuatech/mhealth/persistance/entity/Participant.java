package com.sbs.zuatech.mhealth.persistance.entity;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.*;

import javax.persistence.*;
import java.util.Date;

@Entity
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Participant {

    public enum ParticipationType {
        SURVEY, ADHERENCE;
    }

    @JsonInclude(JsonInclude.Include.NON_EMPTY)
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Setter(AccessLevel.NONE)
    private long participantId;

    private String msisdn;

    @Column(name = "PARTICIPATION_TYPE_ID", nullable = false)
    private String participationTypeId;
    @Enumerated(EnumType.STRING)
    private  ParticipationType participationType;

    private String firstName;

    private String lastName;

    @Column(name = "AUTHORITY_CODE", nullable = false)
    private String authorityCode;

    @JsonIgnore
    @Temporal(TemporalType.TIMESTAMP)
    @Setter(AccessLevel.NONE)
    private Date createdAt;
    @JsonIgnore
    @Temporal(TemporalType.TIMESTAMP)
    @Setter(AccessLevel.NONE)
    private Date updatedAt;

    @PrePersist
    public void updateDates() {
        this.createdAt = new Date();
        this.updatedAt = new Date();
    }

    @PreUpdate
    public void updatedDate() {
        this.updatedAt = new Date();
    }

}
