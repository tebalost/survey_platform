package com.sbs.zuatech.mhealth.api.dto;

import lombok.*;

import javax.xml.bind.annotation.XmlRootElement;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
@ToString(doNotUseGetters = true)
@XmlRootElement(name = "ussdAppRequestInit")
public class USSDAppRequestInit {
    protected String msisdn;
    protected String sessionId;
    protected String network;
    protected String type;
    private String code;
}
