package com.sbs.zuatech.mhealth.api.dto;

import lombok.*;

@NoArgsConstructor
@AllArgsConstructor
@Builder
@ToString
@Data
public class ParticipantAuthorityResponse {
    private String authorityCode;
    private String authorityName;
    private Integer participantCount;
}
