package com.sbs.zuatech.mhealth.api.dto.webhook;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.*;
import lombok.experimental.SuperBuilder;

@Data
@AllArgsConstructor
@NoArgsConstructor
@SuperBuilder
@Builder
@ToString(doNotUseGetters = true)
public class WebHookAdherenceRequest implements WebHookRequest{
    @JsonProperty(value = "Id")
    private String id;
    @JsonProperty(value = "Phone")
    private String phone;
    @JsonProperty(value = "Text")
    private String text;
    @JsonProperty(value = "StartDate")
    private String startDate;
    @JsonProperty(value = "EndDate")
    private String endDate;

// private List<UserMessage> messages = new ArrayList<>();
//    @Data
//    @AllArgsConstructor
//    @NoArgsConstructor
//    @SuperBuilder
//    @Builder
//   public static class UserMessage{
//      private String id;
//      private String phone;
//      private String text;
//      private String startDate;
//      private String endDate;
//   }
}
