package com.sbs.zuatech.mhealth.api.resources;

import com.sbs.zuatech.mhealth.api.dto.ParticipantAuthorityResponse;
import com.sbs.zuatech.mhealth.api.dto.ParticipantReportResponse;
import com.sbs.zuatech.mhealth.api.dto.ParticipantResponse;
import com.sbs.zuatech.mhealth.api.dto.webhook.TempCustomer;
import com.sbs.zuatech.mhealth.exception.InvalidInput;
import com.sbs.zuatech.mhealth.exception.RecordNotFoundInDataBase;
import com.sbs.zuatech.mhealth.service.BusinessUserService;
import com.sbs.zuatech.mhealth.service.ParticipantService;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import reactor.core.publisher.Mono;

import java.util.Date;
import java.util.List;

@RestController
@RequestMapping(path = "/api")
@Data
@Slf4j
public class ParticipantResource {
    final private BusinessUserService businessUserService;
    final private ParticipantService participantService;

    @Autowired
    public ParticipantResource(BusinessUserService businessUserService, ParticipantService participantService) {
        this.businessUserService = businessUserService;
        this.participantService = participantService;
    }

    @GetMapping(path = "/all-authorities")
//    @ApiOperation(value = "all-participant-authorities", tags = "Participant Reports")
    public Mono<ResponseEntity<List<ParticipantAuthorityResponse>>> listAllAuthorities()
            throws InvalidInput, RecordNotFoundInDataBase {

        return Mono.just(ResponseEntity.ok()
                .header("Content-SurveyType", "application/json")
                .body(participantService.listAllAuthorities()));
    }

    @GetMapping(path = "/all-authority-participants/{authority-code}")
//    @ApiOperation(value = "all-authority-participants", tags = "Participant Reports")
    public Mono<ResponseEntity<List<ParticipantResponse>>> listAllAuthorityParticipants(@PathVariable("authority-code") String authorityCode)
            throws InvalidInput, RecordNotFoundInDataBase {
        log.debug("Listing Participants for a Authority -> {}", authorityCode);
        return Mono.just(ResponseEntity.ok()
                .header("Content-SurveyType", "application/json")
                .body(participantService.listAllAuthorityParticipants(authorityCode)));
    }

    @GetMapping(path = "/all-authority-participant-reports/authority/{authority-code}/role/{role-code}")
//    @ApiOperation(value = "authority-participants-reports", tags = "Participant Reports")
    public Mono<ResponseEntity<List<ParticipantReportResponse>>> listAuthorityParticipantReports(@PathVariable("authority-code") String authorityCode,
                                                                                                 @PathVariable("role-code") String roleCode
                                                                                                 )
            throws InvalidInput, RecordNotFoundInDataBase {
        log.debug("Listing Authority Participants report   -> { authority : {} , Role :  {}} ", authorityCode, roleCode);
        return Mono.just(ResponseEntity.ok()
                .header("Content-SurveyType", "application/json")
                .body(participantService.listAuthorityParticipantReports(authorityCode, roleCode)));
    }

    @GetMapping(path = "/all-authority-participant-reports-pages/authority/{authority-code}/role/{role-code}")
    public ResponseEntity<List<ParticipantReportResponse>> getAllAuthorityParticipantReports(
            @RequestParam(defaultValue = "0") Integer pageNo,
            @RequestParam(defaultValue = "10") Integer pageSize,
            @RequestParam(defaultValue = "updatedAt") String sortBy,
            @PathVariable("role-code") String roleCode,
            @PathVariable("authority-code") String authorityCode) throws RecordNotFoundInDataBase, InvalidInput {
        List<ParticipantReportResponse> list = participantService.getAllAuthorityParticipantReports(pageNo, pageSize,
                sortBy, roleCode, authorityCode);

        return new ResponseEntity<List<ParticipantReportResponse>>(list, new HttpHeaders(), HttpStatus.OK);
    }


    @GetMapping(path = "/count-all-authority-participant-report-rows/authority/{authority-code}/role/{role-code}")
    public ResponseEntity<Long> countAllAuthorityParticipantReportRows(
            @PathVariable("role-code") String roleCode,
            @PathVariable("authority-code") String authorityCode) throws RecordNotFoundInDataBase, InvalidInput {
        return new ResponseEntity<Long>(participantService.countAuthorityParticipantReportRows(roleCode, authorityCode),
                new HttpHeaders(), HttpStatus.OK);
    }

    @GetMapping(path = "/all-temp-customers-reports-pages/authority/{authority-code}/role/{role-code}")
    public ResponseEntity<List<TempCustomer>> getTempCustomers(
            @RequestParam(defaultValue = "0") Integer pageNo,
            @RequestParam(defaultValue = "10") Integer pageSize,
            @RequestParam(defaultValue = "updatedAt") String sortBy,
            @PathVariable("role-code") String roleCode,
            @PathVariable("authority-code") String authorityCode) throws RecordNotFoundInDataBase, InvalidInput {
        List<TempCustomer> list = participantService.getAllTempCustomers(pageNo, pageSize,
                sortBy, roleCode, authorityCode);

        return new ResponseEntity<List<TempCustomer>>(list, new HttpHeaders(), HttpStatus.OK);
    }
}
