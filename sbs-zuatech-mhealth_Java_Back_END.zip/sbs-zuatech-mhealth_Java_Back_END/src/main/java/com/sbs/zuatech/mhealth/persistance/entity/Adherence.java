package com.sbs.zuatech.mhealth.persistance.entity;

import lombok.*;

import javax.persistence.*;
import java.util.Date;

@Entity
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Adherence {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Setter(AccessLevel.NONE)
    private long adherenceId;
    @Enumerated(EnumType.STRING)
    private MessageStatus messageStatus;
    private String authorityCode;
    private String userId;
    private String msisdn;
    private String text;
    private String answer;
    private String startDate;
    private String endDate;
    private int type;
    private String correlationId;
    @Temporal(TemporalType.TIMESTAMP)
    @Setter(AccessLevel.NONE)
    private Date createdAt;
    @Temporal(TemporalType.TIMESTAMP)
    @Setter(AccessLevel.NONE)
    private Date updatedAt;

    @Column(name = "ADHERENCE_PAYLOAD_JSON", length = 1024)
    private String adherencePayloadJson;

    @Column(name = "ADHERENCE_PAYLOAD_XML", length = 1024)
    private String adherencePayloadXml;

    @Transient
    private AdherenceHistory adherenceHistory;

    @PrePersist
    public void updateDates() {
        this.createdAt = new Date();
        this.updatedAt = new Date();
        updateHistory();
    }

    @PreUpdate
    public void updatedDate() {
        this.updatedAt = new Date();
        updateHistory();
    }

    private void updateHistory() {
  this.adherenceHistory = new AdherenceHistory();
        this.adherenceHistory.setAdherenceId(this.getAdherenceId());
        this.adherenceHistory.setAdherencePayloadXml(this.getAdherencePayloadXml());
        this.adherenceHistory.setAdherencePayloadJson(this.getAdherencePayloadJson());
        this.adherenceHistory.setMessageStatus(this.getMessageStatus());
        this.adherenceHistory.setMsisdn(this.getMsisdn());
        this.adherenceHistory.setText(this.getText());
        this.adherenceHistory.setUserId(this.getUserId());
        this.adherenceHistory.setEndDate(this.getEndDate());
        this.adherenceHistory.setAnswer(this.getAnswer());
        this.adherenceHistory.setAuthorityCode(this.authorityCode);
        this.adherenceHistory.setCorrelationId(this.correlationId);
        this.adherenceHistory.setType(this.type);

    }
}
