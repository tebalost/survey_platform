package com.sbs.zuatech.mhealth.service;

import com.sbs.zuatech.mhealth.exception.InvalidInput;
import com.sbs.zuatech.mhealth.persistance.entity.MHealthFile;
import com.sbs.zuatech.mhealth.persistance.entity.USSDSessionReport;
import com.sbs.zuatech.mhealth.persistance.repository.MHealthFileRepository;
import com.sbs.zuatech.mhealth.persistance.repository.USSDSessionReportRepository;
import com.sbs.zuatech.mhealth.util.ExcelHelper;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.util.List;

@Service
@Slf4j
public class ExcelService {
    MHealthFileRepository repository;

    USSDSessionReportRepository reportRepository;

    @Autowired
    public ExcelService(MHealthFileRepository repository, USSDSessionReportRepository reportRepository){
        this.repository = repository;
        this.reportRepository = reportRepository;
    }

    public void save(MultipartFile file) {
        try {
            List<MHealthFile> mHealthFiles = ExcelHelper.excelToMHealthFiles(file.getInputStream());
            log.info("New File to be saved ->  {}", mHealthFiles);
            repository.saveAll(mHealthFiles);
        } catch (IOException e) {
            throw new RuntimeException("fail to store excel data: " + e.getMessage());
        }
    }

    public void saveAllMheatlFiles(List<MHealthFile> mHealthFiles) throws InvalidInput {
        try {
            repository.saveAll(mHealthFiles);
        } catch (Exception e) {
            throw new InvalidInput("fail to store excel data: " + e.getMessage());
        }
    }

    public Iterable<MHealthFile> getAllMHealthFiles() {
        return repository.findAll();
    }

    public void saveUSSDSessionReport(List<USSDSessionReport> request) throws InvalidInput {
        try {
            reportRepository.saveAll(request);
        } catch (Exception e) {
            throw new InvalidInput("fail to store excel data: " + e.getMessage());
        }
    }
}
