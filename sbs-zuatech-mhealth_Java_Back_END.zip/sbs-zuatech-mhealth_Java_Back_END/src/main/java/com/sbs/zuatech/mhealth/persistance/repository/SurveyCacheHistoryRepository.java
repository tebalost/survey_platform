package com.sbs.zuatech.mhealth.persistance.repository;

import com.sbs.zuatech.mhealth.persistance.entity.SurveyCacheHistory;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Slice;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.PagingAndSortingRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface SurveyCacheHistoryRepository extends PagingAndSortingRepository<SurveyCacheHistory, Long> {

    int countAllByAuthorityCode(final String authorityCode);

    Iterable<SurveyCacheHistory> findAllByAuthorityCode(String authorityCode);

    Slice<SurveyCacheHistory> findAllByAuthorityCode(String authorityCode, Pageable pageable);

}
