package com.sbs.zuatech.mhealth.api.dto;

public interface UssdHookRequest {
}
