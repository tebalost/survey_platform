package com.sbs.zuatech.mhealth.service;

import com.sbs.zuatech.mhealth.api.dto.webhook.WebHookAdherenceRequest;
import com.sbs.zuatech.mhealth.api.dto.webhook.WebHookSurveyRequest;
import com.sbs.zuatech.mhealth.exception.InvalidInput;

import java.util.List;

public interface WebHookService {
    String processSurveyNotification(WebHookSurveyRequest hookRequest) throws InvalidInput;

    String processAdherenceNotification(List<WebHookAdherenceRequest> requests, int type) throws InvalidInput;
}
