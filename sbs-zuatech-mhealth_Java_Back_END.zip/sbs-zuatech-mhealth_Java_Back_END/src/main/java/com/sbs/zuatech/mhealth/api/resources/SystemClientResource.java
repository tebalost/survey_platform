package com.sbs.zuatech.mhealth.api.resources;

import com.sbs.zuatech.mhealth.exception.InvalidInput;
import com.sbs.zuatech.mhealth.exception.RecordNotFoundInDataBase;
import com.sbs.zuatech.mhealth.persistance.entity.SystemClient;
import com.sbs.zuatech.mhealth.service.SystemClientService;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import reactor.core.publisher.Mono;

import java.util.List;

@RestController
@RequestMapping(path = "/api")
@Data
@Slf4j
public class SystemClientResource {
 final private SystemClientService systemClientService;

    @Autowired
    public SystemClientResource(SystemClientService systemClientService) {
        this.systemClientService = systemClientService;
    }

    @PostMapping(path = "/create-update-client")
//    @ApiOperation(value = "create-update-client", tags = "system-clients")
    public Mono<ResponseEntity<Iterable<SystemClient>>> createUpdateClients(@RequestBody List<SystemClient> requests) throws InvalidInput, RecordNotFoundInDataBase {
        try {
            return Mono.just(ResponseEntity.ok()
                    .header("Content-SurveyType", "application/json")
                    .body(systemClientService.createUpdateClients(requests)));
        }
        catch (Exception e){
            return Mono.just(ResponseEntity.badRequest()
                    .header("Content-SurveyType", "application/json")
                    .body(null));
        }
    }

    @GetMapping(path = "/list-active-authorities")
//    @ApiOperation(value = "list-active-authorities", tags = "system-clients")
    public  Iterable<SystemClient> findAllActive() throws InvalidInput, RecordNotFoundInDataBase{

            return systemClientService.findAllActive();

    }
}
