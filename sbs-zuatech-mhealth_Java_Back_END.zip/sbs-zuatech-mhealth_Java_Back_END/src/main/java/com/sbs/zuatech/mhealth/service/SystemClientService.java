package com.sbs.zuatech.mhealth.service;

import com.sbs.zuatech.mhealth.exception.InvalidInput;
import com.sbs.zuatech.mhealth.exception.RecordNotFoundInDataBase;
import com.sbs.zuatech.mhealth.persistance.entity.SystemClient;

public interface SystemClientService {

    SystemClient createUpdateClient(final SystemClient systemClient) throws InvalidInput, RecordNotFoundInDataBase;

    Iterable<SystemClient> createUpdateClients(final Iterable<SystemClient> systemClients) throws InvalidInput,
            RecordNotFoundInDataBase;

    Iterable<SystemClient> findAll() throws InvalidInput, RecordNotFoundInDataBase;

    Iterable<SystemClient> findAllActive() throws InvalidInput, RecordNotFoundInDataBase;
}
