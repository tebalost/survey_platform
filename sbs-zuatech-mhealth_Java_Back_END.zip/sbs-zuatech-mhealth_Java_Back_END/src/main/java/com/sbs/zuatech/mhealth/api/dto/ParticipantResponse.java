package com.sbs.zuatech.mhealth.api.dto;

import lombok.*;

@NoArgsConstructor
@AllArgsConstructor
@Builder
@ToString
@Data
public class ParticipantResponse {
    private String msisdn;
    private String status;
    private Integer surveyCount;
    private Integer adherenceCount;
}
