package com.sbs.zuatech.mhealth.config.properties;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

@Component
@ConfigurationProperties(prefix = "mhealth")
@Setter
@Getter
@ToString
public class MHealthProperties {
    private String grantType;
    private String clientId;
    private String clientSecret;
    private String scope;
    private String urlSurvey;
    private String urlIdentity;
    private String urlProfile;
}
