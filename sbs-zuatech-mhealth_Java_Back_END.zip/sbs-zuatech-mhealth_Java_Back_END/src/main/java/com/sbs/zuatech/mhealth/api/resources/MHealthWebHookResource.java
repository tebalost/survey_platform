package com.sbs.zuatech.mhealth.api;

import com.sbs.zuatech.mhealth.api.dto.webhook.WebHookAdherenceRequest;
import com.sbs.zuatech.mhealth.api.dto.webhook.WebHookSurveyRequest;
import com.sbs.zuatech.mhealth.exception.InvalidInput;
import com.sbs.zuatech.mhealth.service.WebHookService;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping(path = "/api")
@Data
@Slf4j
public class MHealthWebHookResource {
    public static String TAG_MHEALTH_WEBHOOK = "mHealth Survey";

    private WebHookService webHookService;

    @Autowired
    public MHealthWebHookResource(WebHookService webHookService) {
        this.webHookService = webHookService;
    }

    @GetMapping(path = "/ping-webhook")
    public String ping() {
        return "pong";
    }

    @PostMapping(path = "/execute-mhealth-survey")
//    @ApiOperation(value = "This is the call back that the Survey Engine calls in order to execute the survey", tags = "mHealth Survey")
    public void processCallBackSurvey(@RequestBody WebHookSurveyRequest request) throws InvalidInput {
        webHookService.processSurveyNotification(request);
    }

    @PostMapping(path = "/execute-mhealth-adherence")
//    @ApiOperation(value = "This is the call back that the Survey Engine calls in order to execute the survey", tags = "mHealth Survey")
    public void processCallBackAdherence(@RequestBody List<WebHookAdherenceRequest> requests) throws InvalidInput {
        webHookService.processAdherenceNotification(requests,0);
    }

    @PostMapping(path = "/execute-mhealth-adherence-type-1")
//    @ApiOperation(value = "This is the call back that the Survey Engine calls in order to execute the survey", tags = "mHealth Survey")
    public void processCallBackAdherence1(@RequestBody List<WebHookAdherenceRequest> requests) throws InvalidInput {
        webHookService.processAdherenceNotification(requests, 1);
    }

    @PostMapping(path = "/execute-mhealth-adherence-type-2")
//    @ApiOperation(value = "This is the call back that the Survey Engine calls in order to execute the survey", tags = "mHealth Survey")
    public void processCallBackAdherence2(@RequestBody List<WebHookAdherenceRequest> requests) throws InvalidInput {
        webHookService.processAdherenceNotification(requests,2);
    }
}
