package com.sbs.zuatech.mhealth.config;

import com.squareup.okhttp.OkHttpClient;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.filter.CommonsRequestLoggingFilter;

@Configuration
public class WebConfig {

    @Bean
    public CommonsRequestLoggingFilter requestLoggingFilter() {
        CommonsRequestLoggingFilter loggingFilter = new CommonsRequestLoggingFilter();
        loggingFilter.setIncludeClientInfo(true);
        loggingFilter.setIncludeQueryString(true);
        loggingFilter.setIncludePayload(true);
        loggingFilter.setMaxPayloadLength(20000);

        loggingFilter.setBeforeMessagePrefix("\n\n");
        loggingFilter.setBeforeMessageSuffix("\n\n");

        loggingFilter.setAfterMessagePrefix("\n\n");
        loggingFilter.setAfterMessageSuffix("\n\n");
        return loggingFilter;
    }

    @Bean
    public RestTemplate restTemplate() throws Exception {
        return new RestTemplate();
    }

    @Bean
    public OkHttpClient okHttpClient() {
        return new OkHttpClient();
    }
}
