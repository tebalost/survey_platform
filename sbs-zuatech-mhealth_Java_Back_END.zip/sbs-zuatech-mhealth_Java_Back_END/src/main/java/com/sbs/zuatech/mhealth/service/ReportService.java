package com.sbs.zuatech.mhealth.service;

import com.sbs.zuatech.mhealth.api.dto.reports.DashboardTopMenuStats;
import com.sbs.zuatech.mhealth.api.dto.reports.TypeStats;
import com.sbs.zuatech.mhealth.exception.InvalidInput;
import com.sbs.zuatech.mhealth.exception.RecordNotFoundInDataBase;

import java.util.Arrays;
import java.util.List;

public interface ReportService {
    List<String> ROLE_SUPER  = Arrays.asList("SUPER_ADMIN", "SBS");
    DashboardTopMenuStats getMenuStats() throws InvalidInput;

    DashboardTopMenuStats getMenuStats(String authorityCode, String roleCode) throws InvalidInput;

    List<TypeStats> getSurveyStates(String authorityCode, String roleCode)
            throws InvalidInput, RecordNotFoundInDataBase;

    List<TypeStats> getAdherenceStates(String authorityCode, String roleCode)
            throws InvalidInput, RecordNotFoundInDataBase;
}
