package com.sbs.zuatech.mhealth.config;

import com.sbs.zuatech.mhealth.integration.soap.SOAPConnector;
import com.sun.xml.bind.marshaller.NamespacePrefixMapper;
import lombok.extern.slf4j.Slf4j;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.oxm.jaxb.Jaxb2Marshaller;
import org.springframework.ws.client.core.WebServiceTemplate;

import javax.xml.bind.Marshaller;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.security.KeyManagementException;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.UnrecoverableKeyException;
import java.security.cert.CertificateException;
import java.util.HashMap;
import java.util.Map;

@Configuration
@Slf4j
public class HttpConfig {

    private static Map<String, Object> getMarshallerDefaultProperties() {
        final Map<String, Object> props = new HashMap<>();
        props.put(Marshaller.JAXB_ENCODING, StandardCharsets.UTF_8.name());
        props.put(Marshaller.JAXB_FRAGMENT, Boolean.TRUE);
        props.put(Marshaller.JAXB_FORMATTED_OUTPUT, Boolean.TRUE);
        props.put("com.sun.xml.bind.namespacePrefixMapper", new DefaultNamespacePrefixMapper());
        return props;
    }

    private static Jaxb2Marshaller activateLoggingValidation(final Jaxb2Marshaller marshaller) {
        try {
            marshaller.afterPropertiesSet();
        } catch (Exception e) {
            log.error("Exception when creating marshaller", e);
        }
        marshaller.setValidationEventHandler(event -> {
            log.error(event.getMessage());
            return true;
        });
        return marshaller;
    }

    @Bean
    public Jaxb2Marshaller jaxb2Marshaller() {
        Jaxb2Marshaller jaxb2Marshaller = new Jaxb2Marshaller();
//        jaxb2Marshaller.setPackagesToScan("com.sbs.zuatech.mhealth.api.dto.menu");
        jaxb2Marshaller.setContextPath("com.sbs.zuatech.mhealth.api.dto.menu");
        jaxb2Marshaller.setMarshallerProperties(getMarshallerDefaultProperties());
        return activateLoggingValidation(jaxb2Marshaller);
    }

    @Bean
    public SOAPConnector soapConnector() {
        SOAPConnector client = new SOAPConnector();
        client.setDefaultUri("http://bms27.vine.co.za:80/webservice/services/ApplinkUpload");
        client.setMarshaller(jaxb2Marshaller());
        client.setUnmarshaller(jaxb2Marshaller());
        return client;
    }

    @Bean
    public WebServiceTemplate webServiceTemplate() throws CertificateException,
            UnrecoverableKeyException,
            NoSuchAlgorithmException,
            KeyStoreException,
            KeyManagementException,
            IOException {
        WebServiceTemplate webServiceTemplate = new WebServiceTemplate();
        webServiceTemplate.setMarshaller(jaxb2Marshaller());
        webServiceTemplate.setUnmarshaller(jaxb2Marshaller());
        return webServiceTemplate;
    }

    static class DefaultNamespacePrefixMapper extends NamespacePrefixMapper {

        private Map<String, String> namespaceMap = new HashMap<>();

        /**
         * Create mappings.
         */
        public DefaultNamespacePrefixMapper() {
            namespaceMap.put("http://www.w3.org/2001/XMLSchema-instance", "xsi");
            namespaceMap.put("https://www.intertech.com/software-consulting-services/", "consult");
            namespaceMap.put("http://www.w3.org/2003/05/soap-envelope/", "soap");
            namespaceMap.put("http://tempuri.org/xsd/", "xsd");
        }

        public String getPreferredPrefix(String namespaceUri, String suggestion, boolean requirePrefix) {
            return namespaceMap.getOrDefault(namespaceUri, suggestion);
        }
    }

}
