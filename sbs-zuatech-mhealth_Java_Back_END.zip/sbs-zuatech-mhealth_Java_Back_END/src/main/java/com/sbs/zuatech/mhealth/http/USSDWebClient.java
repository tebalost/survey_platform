package com.sbs.zuatech.mhealth.http;

import org.springframework.stereotype.Component;

@Component
public class USSDWebClient {

}
