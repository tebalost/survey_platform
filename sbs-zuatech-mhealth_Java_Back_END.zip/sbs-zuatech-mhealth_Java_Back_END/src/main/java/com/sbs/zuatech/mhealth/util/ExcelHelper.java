package com.sbs.zuatech.mhealth.util;


import com.sbs.zuatech.mhealth.persistance.entity.MHealthFile;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class ExcelHelper {
    public static String TYPE = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
    static String[] HEADERs = { "Id", "Title", "Description", "Published" };
    static String SHEET = "TestFile";

    public static boolean hasExcelFormat(MultipartFile file) {

        if (!TYPE.equals(file.getContentType())) {
            return false;
        }

        return true;
    }

    public static List<MHealthFile> excelToMHealthFiles(InputStream is) {
        try {
            Workbook workbook = new XSSFWorkbook(is);

//            Sheet sheet = workbook.getSheet(SHEET);

            Sheet sheet = workbook.getSheetAt(0);
            Iterator<Row> rows = sheet.iterator();

            List<MHealthFile> MHealthFiles = new ArrayList<MHealthFile>();

            int rowNumber = 0;
            while (rows.hasNext()) {
                Row currentRow = rows.next();

                // skip header
                if (rowNumber == 0) {
                    rowNumber++;
                    continue;
                }

                Iterator<Cell> cellsInRow = currentRow.iterator();

                MHealthFile MHealthFile = new MHealthFile();

                int cellIdx = 0;
                while (cellsInRow.hasNext()) {
                    Cell currentCell = cellsInRow.next();

                    switch (cellIdx) {
                        case 0:
                            MHealthFile.setMsisdn(currentCell.getStringCellValue());
                            break;

                        case 1:
                            MHealthFile.setTypeId(currentCell.getStringCellValue());
                            break;

                        case 2:
                            MHealthFile.setTypeCode(currentCell.getStringCellValue());
                            break;

                        case 3:
                            MHealthFile.setTypeName(currentCell.getStringCellValue());
                            break;

                        case 4:
                            MHealthFile.setAuthority(currentCell.getStringCellValue());
                            break;

                        case 5:
                            MHealthFile.setCountry(currentCell.getStringCellValue());
                            break;
                        default:
                            break;
                    }

                    cellIdx++;
                }

                MHealthFiles.add(MHealthFile);
            }

            workbook.close();

            return MHealthFiles;
        } catch (IOException e) {
            throw new RuntimeException("fail to parse Excel file: " + e.getMessage());
        }
    }
}
