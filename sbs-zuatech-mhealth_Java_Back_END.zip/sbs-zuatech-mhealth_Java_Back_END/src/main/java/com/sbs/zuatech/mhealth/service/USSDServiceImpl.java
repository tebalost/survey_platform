package com.sbs.zuatech.mhealth.service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.sbs.zuatech.mhealth.api.dto.*;
import com.sbs.zuatech.mhealth.api.dto.menu.SurveyAnswer;
import com.sbs.zuatech.mhealth.api.dto.menu.SurveyMenu;
import com.sbs.zuatech.mhealth.exception.InvalidInput;
import com.sbs.zuatech.mhealth.exception.MHealthSurveyCallFailed;
import com.sbs.zuatech.mhealth.integration.MHealthClient;
import com.sbs.zuatech.mhealth.persistance.entity.Adherence;
import com.sbs.zuatech.mhealth.persistance.entity.MessageStatus;
import com.sbs.zuatech.mhealth.persistance.entity.SurveyCache;
import com.sbs.zuatech.mhealth.persistance.entity.SurveyCacheHistory;
import com.sbs.zuatech.mhealth.persistance.repository.AdherenceHistoryRepository;
import com.sbs.zuatech.mhealth.persistance.repository.AdherenceRepository;
import com.sbs.zuatech.mhealth.persistance.repository.SurveyCacheHistoryRepository;
import com.sbs.zuatech.mhealth.persistance.repository.SurveyCacheRepository;
import com.sbs.zuatech.mhealth.util.JsonUtil;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.xml.transform.StringSource;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;
import javax.xml.bind.Unmarshaller;
import java.io.StringWriter;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.StreamSupport;

import static org.springframework.util.StringUtils.hasLength;

@Service
@Slf4j
public class USSDServiceImpl implements USSDService {

    private MHealthClient mHealthClient;

    private SurveyCacheRepository surveyCacheRepository;

    private SurveyCacheHistoryRepository cacheHistoryRepository;

    private AdherenceRepository adherenceRepository;

    private AdherenceHistoryRepository adherenceHistoryRepository;

    @Autowired
    public USSDServiceImpl(
            MHealthClient mHealthClient, SurveyCacheRepository surveyCacheRepository,
            SurveyCacheHistoryRepository cacheHistoryRepository,
            AdherenceRepository adherenceRepository,
            AdherenceHistoryRepository adherenceHistoryRepository) {
        this.mHealthClient = mHealthClient;
        this.surveyCacheRepository = surveyCacheRepository;
        this.cacheHistoryRepository = cacheHistoryRepository;
        this.adherenceRepository = adherenceRepository;
        this.adherenceHistoryRepository = adherenceHistoryRepository;
    }

    public USSDAppResponse processSurveyNotification(String xmlInstruction) throws InvalidInput {
        return getUssdAppResponse(xmlInstruction);
    }

    private <T> Unmarshaller localMarshaller(Class<T> tClass) {
        try {
            JAXBContext jaxbContext = JAXBContext.newInstance(tClass);
            Unmarshaller jaxbMarshaller = jaxbContext.createUnmarshaller();
            return jaxbMarshaller;

        } catch (JAXBException e) {
            return null;
        }
    }

    private USSDAppResponse getUssdAppResponse(String xmlInstruction) {
        try {
            SurveyMenu surveyMenu = null;

            if (xmlInstruction.contains("<type>initial</type>")) {
                USSDAppRequestInit ussdAppRequest = (USSDAppRequestInit) localMarshaller(USSDAppRequestInit.class).unmarshal(new StringSource(xmlInstruction));

                SurveyCache surveyCache = StreamSupport.stream(surveyCacheRepository.findAllByMsisdnAndMessageStatus(ussdAppRequest.getMsisdn(), MessageStatus.DISPATCHED).spliterator(), false)
                        .findFirst()
                        .orElseThrow(InvalidInput::new);
                // Get all details from the Survey
                surveyMenu = mHealthClient.findSurveyFirstMenu(surveyCache.getSurveyId(), surveyCache.getSurveyUserId());

                // update DB
                surveyCache.setNetwork(ussdAppRequest.getNetwork());
                updateSurveyCache(xmlInstruction, surveyMenu, surveyCache);

            } else if (xmlInstruction.contains("<type>action</type>")) {
                USSDAppRequestAction ussdAppRequest = (USSDAppRequestAction) localMarshaller(USSDAppRequestAction.class).unmarshal(new StringSource(xmlInstruction));
                Integer participantAnswerOrder = Integer.valueOf(ussdAppRequest.getFields().getField().getValue());

                SurveyCache surveyCache = StreamSupport.stream(surveyCacheRepository.findAllByMsisdnAndMessageStatus(ussdAppRequest.getMsisdn(), MessageStatus.INCOMPLETE).spliterator(), false)
                        .findFirst()
                        .orElseThrow(InvalidInput::new);

                final String participantQuestionId = surveyCache.getSurveyTakenQuestionId();
                surveyMenu = JsonUtil.DeSerializeString(surveyCache.getSurveyPayloadJson(), SurveyMenu.class);

                String pickedAnswerId = "";
                for (var answer : surveyMenu.getAnswers())
                    if (hasLength(participantAnswerOrder + "")
                            && answer.getOrder().equals(participantAnswerOrder)) {
                        pickedAnswerId = answer.getAnswerId();
                        surveyCache.setAnswerId(answer.getAnswerId());
                        surveyCache.setAnswer(answer.getValue());
                    }

                // Submit the answer
                List<SurveyAnswer.Answer> answerList = new ArrayList<>();
                answerList.add(SurveyAnswer.Answer.builder().answerId(pickedAnswerId).build());

                // Submit the answer and check that it was accepted
                if (mHealthClient.submitSurveyAnswer(surveyCache.getSurveyId(), surveyCache.getSurveyUserId(), participantQuestionId,
                        SurveyAnswer.builder()
                                .answers(answerList)
                                .build())) {

                    surveyMenu = mHealthClient.findSurveyNextMenu(surveyCache.getSurveyId(), surveyCache.getSurveyUserId(), participantQuestionId);
                    log.info("A new Menu is retrieved  from the survey engine -> Survey Details  :  {}", surveyMenu);

                    if (surveyMenu == null) {
                        // Finalise Survey
                        mHealthClient.patchSurvey(surveyCache.getSurveyId(), surveyCache.getSurveyUserId());

                        //update DB
                        surveyCache.setMessageStatus(MessageStatus.COMPLETED);
                        surveyCache.setQuestion("");
                        surveyCacheRepository.save(surveyCache);
                        cacheHistoryRepository.save(surveyCache.getSurveyCacheHistory());

                        // Update User
                        return USSDAppResponse
                                .builder()
                                .responseType("string")
                                .state("End")
                                .prompt("Thank you, no more questions on survey :" + surveyCache.getSurveyName())
                                .build();
                    } else {
                        updateSurveyCache(xmlInstruction, surveyMenu, surveyCache);
                    }
                }
            } else if (xmlInstruction.contains("<type>abort</type>")) {
                return null;
            }

            StringBuilder answers = new StringBuilder();
            surveyMenu.getAnswers().forEach(
                    answer -> {
                        answers.append("\n");
                        answers.append(answer.getOrder());
                        answers.append(". ");
                        answers.append(answer.getValue());
                    }
            );

            return USSDAppResponse
                    .builder()
                    .responseType("string")
                    .state("NextState")
                    .prompt(surveyMenu.getValue() + " " + answers.toString())
                    .build();
        } catch (Exception e) {
            log.error("Something not ok ", e);
        }
        return null;
    }

    private void updateSurveyCache(String xmlInstruction, SurveyMenu surveyMenu, SurveyCache surveyCache)
            throws com.fasterxml.jackson.core.JsonProcessingException {
        final String jsonSurveyMenu = JsonUtil.serializeObject(surveyMenu);
        final String questionId = surveyMenu.getQuestionId();

        surveyCache.setUssdPayloadXml(xmlInstruction);
        surveyCache.setSurveyPayloadJson(jsonSurveyMenu);
        surveyCache.setMessageStatus(MessageStatus.INCOMPLETE);
        surveyCache.setSurveyTakenQuestionId(questionId);
        surveyCache.setQuestion(surveyMenu.getValue());
        surveyCache.setQuestionId(questionId);

        surveyCacheRepository.save(surveyCache);

        SurveyCacheHistory cacheHistory = surveyCache.getSurveyCacheHistory();
        cacheHistoryRepository.save(cacheHistory);
    }

    @Override
    public String processSurveyNotificationMarshalled(String xmlInstruction) throws InvalidInput {

        USSDAppResponse ussdAppResponse = getUssdAppResponse(xmlInstruction);
        try {
            if (ussdAppResponse == null)
                return null;

            JAXBContext jaxbContext = JAXBContext.newInstance(USSDAppResponse.class);
            Marshaller jaxbMarshaller = jaxbContext.createMarshaller();
            jaxbMarshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, Boolean.TRUE);
            StringWriter sw = new StringWriter();
            jaxbMarshaller.marshal(ussdAppResponse, sw);
            return sw.toString();

        } catch (JAXBException e) {
            log.error("Unmarshalling of xml failed ", e);
            return null;
        }

    }

    @Override
    public String processAdherentNotification(String xmlInstruction) throws InvalidInput {
        String xmlInstructionMarshal = xmlInstruction.replace("+xmlns:xsi=http://www.w3.org/2001/XMLSchema-instance", "");
        xmlInstructionMarshal = xmlInstructionMarshal.replace("xmlns:xsi=http://www.w3.org/2001/XMLSchema-instance", "");
        try {
            //Check what kind of Status we got

            if (xmlInstruction.contains("<responseType>reply</responseType>")) {
                AdherenceSmsResponseReply smsResponse = (AdherenceSmsResponseReply) localMarshaller(AdherenceSmsResponseReply.class).unmarshal(new StringSource(xmlInstructionMarshal));
                Adherence adherence = StreamSupport.stream(adherenceRepository.findAllByMsisdnAndMessageStatusNotOrderByAdherenceIdDesc(smsResponse.getRecipient().getMsisdn(), MessageStatus.COMPLETED).spliterator(), false)
                        .findFirst()
                        .orElseThrow(InvalidInput::new);

                adherence.setAnswer(smsResponse.getResponse());
                adherence.setAdherencePayloadXml(xmlInstruction);
                adherence.setMessageStatus(MessageStatus.COMPLETED);
                adherenceRepository.save(adherence);

                adherenceHistoryRepository.save(adherence.getAdherenceHistory());

                AdherenceRequest adherenceRequest = new AdherenceRequest();
                adherenceRequest.setEndDate(adherence.getEndDate());
                adherenceRequest.setStartDate(adherence.getStartDate());
                adherenceRequest.setPatientEatDrug(!(smsResponse.getResponse().equalsIgnoreCase("Yes") || smsResponse.getResponse().equalsIgnoreCase("1")));
                try {
                    //Check Adherence for today, and then check the type
                    //PATCH the relevant type
                    mHealthClient.patchProfileAdherence(adherence.getUserId(), JsonUtil.serializeObject(adherenceRequest), adherence.getType());

                } catch (JsonProcessingException e) {
                    log.error("Unmarshalling of xml failed ", e);
                } catch (MHealthSurveyCallFailed e) {
                    log.error("Failed to call MSurvey for entity Patch ", e);
                }

            } else if (xmlInstruction.contains("<responseType>error</responseType>")) {
                // Save the Error against the number
                AdherenceSmsResponseError smsResponse = (AdherenceSmsResponseError) localMarshaller(AdherenceSmsResponseError.class).unmarshal(new StringSource(xmlInstructionMarshal));
                Adherence adherence = StreamSupport.stream(adherenceRepository.findAllByMsisdnAndMessageStatusNotOrderByAdherenceIdDesc(smsResponse.getRecipient().getMsisdn(), MessageStatus.COMPLETED).spliterator(), false)
                        .findFirst()
                        .orElseThrow(InvalidInput::new);
                adherence.setAdherencePayloadXml(xmlInstruction);
                adherence.setMessageStatus(MessageStatus.ERROR);
                adherenceRepository.save(adherence);

                adherenceHistoryRepository.save(adherence.getAdherenceHistory());
                return "Something went wrong with the SMS we sent.";

            } else if (xmlInstruction.contains("<responseType>receipt</responseType>")) {
                // Save the Receipt  against the number
                AdherenceSmsResponseReceipt smsResponse = (AdherenceSmsResponseReceipt) localMarshaller(AdherenceSmsResponseReceipt.class).unmarshal(new StringSource(xmlInstructionMarshal));
                Adherence adherence = StreamSupport.stream(adherenceRepository.findAllByMsisdnAndMessageStatusNotOrderByAdherenceIdDesc(smsResponse.getRecipient().getMsisdn(), MessageStatus.DISPATCHED).spliterator(), false)
                        .findFirst()
                        .orElseThrow(InvalidInput::new);
                adherence.setAdherencePayloadXml(xmlInstruction);
                adherence.setMessageStatus(MessageStatus.DELIVERED);
                adherenceRepository.save(adherence);

                adherenceHistoryRepository.save(adherence.getAdherenceHistory());
                return "Message Delivered Successfully";
            }
            return "success";
        } catch (JAXBException e) {
            log.error("Unmarshalling of xml failed ", e);
            return "Something was wrong with your reply";
        } catch (Exception e) {
            log.error("Processing of the response failed", e);
            return "Something was wrong with your reply";
        }

    }
}
