package com.sbs.zuatech.mhealth.api.dto.webhook;

public interface WebHookRequest {
}
