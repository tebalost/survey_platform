package com.sbs.zuatech.mhealth.service;

import com.sbs.zuatech.mhealth.api.dto.ParticipantAuthorityResponse;
import com.sbs.zuatech.mhealth.api.dto.ParticipantReportResponse;
import com.sbs.zuatech.mhealth.api.dto.ParticipantResponse;
import com.sbs.zuatech.mhealth.api.dto.webhook.TempCustomer;
import com.sbs.zuatech.mhealth.exception.InvalidInput;
import com.sbs.zuatech.mhealth.exception.RecordNotFoundInDataBase;

import java.util.Arrays;
import java.util.List;

public interface ParticipantService {
    List<String> ROLE_SUPER  = Arrays.asList("SUPER_ADMIN", "SBS");

    List<ParticipantAuthorityResponse> listAllAuthorities()
            throws InvalidInput, RecordNotFoundInDataBase ;

    List<ParticipantReportResponse> listAllAuthorityParticipantReports()
            throws InvalidInput, RecordNotFoundInDataBase ;


    List<ParticipantResponse> listAllAuthorityParticipants( String authorityCode)
            throws InvalidInput, RecordNotFoundInDataBase ;

    List<ParticipantReportResponse> listAuthorityParticipantReports( String authorityCode, String roleCode)
            throws InvalidInput, RecordNotFoundInDataBase ;

    List<ParticipantReportResponse> getAllAuthorityParticipantReports( Integer pageNo, Integer pageSize, String sortBy,
                                                                        String roleCode, String authorityCode)
            throws InvalidInput, RecordNotFoundInDataBase ;


    Long countAuthorityParticipantReportRows(  String roleCode, String authorityCode)
            throws InvalidInput, RecordNotFoundInDataBase ;

    List<TempCustomer> getAllTempCustomers(Integer pageNo, Integer pageSize, String sortBy,
                                                         String roleCode, String authorityCode)
            throws InvalidInput, RecordNotFoundInDataBase ;
}
