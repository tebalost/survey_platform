package com.sbs.zuatech.mhealth.api.dto.webhook;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.*;
import lombok.experimental.SuperBuilder;

@Data
@AllArgsConstructor
@NoArgsConstructor
@SuperBuilder
@Builder
@ToString(doNotUseGetters = true)
public class WebHookSurveyRequest implements WebHookRequest{
    @JsonProperty(value = "Id")
    private String surveyId;
    @JsonProperty(value = "Name")
    private String surveyName;
    @JsonProperty(value = "Finish")
//    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-ddTHH:mm:ss.Z")
    private String surveyClosure;
}
