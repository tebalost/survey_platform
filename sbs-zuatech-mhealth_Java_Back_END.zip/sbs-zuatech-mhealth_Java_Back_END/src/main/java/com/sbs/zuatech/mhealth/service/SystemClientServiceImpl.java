package com.sbs.zuatech.mhealth.service;

import com.sbs.zuatech.mhealth.exception.InvalidInput;
import com.sbs.zuatech.mhealth.exception.RecordNotFoundInDataBase;
import com.sbs.zuatech.mhealth.persistance.entity.SystemClient;
import com.sbs.zuatech.mhealth.persistance.repository.SystemClientRepository;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
@Slf4j
public class SystemClientServiceImpl implements  SystemClientService {
 final SystemClientRepository systemClientRepository;
    @Autowired
    public SystemClientServiceImpl(SystemClientRepository systemClientRepository){
  this.systemClientRepository = systemClientRepository;
    }

    @Override
    public SystemClient createUpdateClient(SystemClient systemClient) throws InvalidInput, RecordNotFoundInDataBase {
        return null;
    }

    @Override
    public Iterable<SystemClient> createUpdateClients(Iterable<SystemClient> systemClients) throws InvalidInput, RecordNotFoundInDataBase {
        try {
//            systemClients.forEach(
//                    systemClient -> {
//
//                    }
//            );

            return systemClientRepository.saveAll(systemClients);
        }catch (Exception e){
         log.error("Saving of the clients failed due to the error -> ", e);
         throw new InvalidInput(e.getMessage());
        }
    }

    @Override
    public Iterable<SystemClient> findAll() throws InvalidInput, RecordNotFoundInDataBase {
        return null;
    }

    @Override
    public Iterable<SystemClient> findAllActive() throws InvalidInput, RecordNotFoundInDataBase {
        return systemClientRepository.findAllByClientStatus(SystemClient.ClientStatus.ACTIVE);
    }
}
