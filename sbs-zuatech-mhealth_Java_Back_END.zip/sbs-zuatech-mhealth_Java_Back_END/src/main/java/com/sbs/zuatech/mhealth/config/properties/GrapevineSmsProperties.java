package com.sbs.zuatech.mhealth.config.properties;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

@Component
@ConfigurationProperties(prefix = "grapevine")
@Setter
@Getter
@ToString
public class GrapevineSmsProperties {
    private String hostUrl;
    private String affiliateCode;
    private String authenticationCode;
    private String dialingCode;
}
