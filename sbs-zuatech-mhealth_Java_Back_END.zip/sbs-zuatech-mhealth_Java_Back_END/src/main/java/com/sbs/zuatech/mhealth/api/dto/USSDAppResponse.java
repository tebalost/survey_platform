package com.sbs.zuatech.mhealth.api.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.NoArgsConstructor;
import lombok.ToString;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

@NoArgsConstructor
@AllArgsConstructor
@Builder
@ToString
@XmlRootElement(name = "ussdAppResponse")
public class USSDAppResponse {
    @XmlElement
    protected String prompt;
    @XmlElement
    protected String responseType;
    @XmlElement
    protected String state;
}
