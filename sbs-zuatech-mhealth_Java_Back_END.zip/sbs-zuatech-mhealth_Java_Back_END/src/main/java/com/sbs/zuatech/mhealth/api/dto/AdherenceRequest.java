package com.sbs.zuatech.mhealth.api.dto;

import lombok.*;

@NoArgsConstructor
@AllArgsConstructor
@Builder
@ToString
@Data
//@XmlRootElement
public class AdherenceRequest {
    private boolean patientEatDrug;
    private String startDate;
    private String endDate;

}
