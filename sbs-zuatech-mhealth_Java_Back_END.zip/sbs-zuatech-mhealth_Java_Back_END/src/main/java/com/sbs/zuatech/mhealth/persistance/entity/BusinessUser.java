package com.sbs.zuatech.mhealth.persistance.entity;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.*;
import org.hibernate.annotations.CacheConcurrencyStrategy;
import org.springframework.util.ObjectUtils;
import org.springframework.util.StringUtils;

import javax.persistence.*;
import java.util.Date;

@Entity
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
@org.hibernate.annotations.Cache(usage = CacheConcurrencyStrategy.READ_WRITE)

@Table(uniqueConstraints = {@UniqueConstraint(columnNames = "email")})
public class BusinessUser {

    public enum UserStatus {
        ACTIVE, INACTIVE, BLOCKED, PENDING
    }

    public enum Role {
        SUPER_ADMIN, ADMIN, NORMAL_USER, SBS
    }

    @Schema(description = "Unique identifier of the BusinessUser.",
            example = "1", required = true)
    @JsonInclude(JsonInclude.Include.NON_EMPTY)
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Setter(AccessLevel.NONE)
    private long businessUserId;

    @Enumerated(EnumType.STRING)
    private Role role;

    private String email;

    private String authorityCode; // { "name":"XASDD", "code":"wqeqwqeq", "location":"aeqwewqe", "country":"rsa"}
    @Enumerated(EnumType.STRING)
    private UserStatus userStatus;

    private String firstName;

    private String lastName;

    private String imageUrl;

    @Column(columnDefinition="LONGTEXT")
    private String imageString;

    @JsonIgnore
    @Temporal(TemporalType.TIMESTAMP)
    @Setter(AccessLevel.NONE)
    private Date createdAt;
    @JsonIgnore
    @Temporal(TemporalType.TIMESTAMP)
    @Setter(AccessLevel.NONE)
    private Date updatedAt;

    @PrePersist
    public void updateDates() {
        this.createdAt = new Date();
        this.updatedAt = new Date();

        if(ObjectUtils.isEmpty(this.role) || !StringUtils.hasLength(this.role.name())){
            this.role = Role.NORMAL_USER;
        }
    }

    @PreUpdate
    public void updatedDate() {
        this.updatedAt = new Date();
    }

}
