package com.sbs.zuatech.mhealth.persistance.repository;

import com.sbs.zuatech.mhealth.persistance.entity.SystemClient;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface SystemClientRepository extends CrudRepository<SystemClient, Long> {
    Optional<SystemClient> findByCode(String code);
    Iterable<SystemClient> findAllByClientStatus(SystemClient.ClientStatus clientStatus);
}
