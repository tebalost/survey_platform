package com.sbs.zuatech.mhealth.integration;

import com.sbs.zuatech.mhealth.api.dto.menu.SurveyAnswer;
import com.sbs.zuatech.mhealth.api.dto.menu.SurveyMenu;
import com.sbs.zuatech.mhealth.exception.MHealthSurveyCallFailed;
import com.sbs.zuatech.mhealth.integration.model.SurveyParticipant;

import java.util.List;

public interface MHealthClient {
    String FEATURE_PHONE_URI = "/feature-phones/";

    /**
     * No. 2
     *
     * @param surveyId
     * @return
     * @throws MHealthSurveyCallFailed
     */
    List<SurveyParticipant> findSurveyParticipants(final String surveyId) throws MHealthSurveyCallFailed;

    /**
     * No 3.
     *
     * @param surveyId
     * @param userId
     * @return
     * @throws MHealthSurveyCallFailed
     */
    SurveyMenu findSurveyFirstMenu(final String surveyId, final String userId) throws MHealthSurveyCallFailed;

    /**
     * No. 4
     *
     * @param surveyId
     * @param userId
     * @param questionId
     * @return
     * @throws MHealthSurveyCallFailed
     */
    boolean submitSurveyAnswer(final String surveyId, final String userId, String questionId, SurveyAnswer surveyAnswer) throws MHealthSurveyCallFailed;

    /**
     * No. 5
     *
     * @param surveyId
     * @param userId
     * @param questionId
     * @return
     * @throws MHealthSurveyCallFailed
     */
    SurveyMenu findSurveyNextMenu(final String surveyId, final String userId, String questionId) throws MHealthSurveyCallFailed;

    /**
     * No. 6
     *
     * @param surveyId
     * @param userId
     */
    void patchSurvey(final String surveyId, final String userId);


    void patchProfileAdherence(final String adherenceId, final String body, int type) throws MHealthSurveyCallFailed;;

}
