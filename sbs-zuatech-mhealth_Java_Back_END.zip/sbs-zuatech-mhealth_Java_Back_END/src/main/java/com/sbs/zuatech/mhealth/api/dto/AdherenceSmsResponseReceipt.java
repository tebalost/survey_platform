package com.sbs.zuatech.mhealth.api.dto;

import lombok.*;

import javax.xml.bind.annotation.XmlRootElement;
import java.util.Date;

@NoArgsConstructor
@AllArgsConstructor
@Builder
@ToString
@Data
@XmlRootElement(name = "gviSmsResponseReceipt")
public class AdherenceSmsResponseReceipt {
    private Date responseDateTime;
    private Recipient recipient;
    private String responseType;
    private String response;

    @NoArgsConstructor
    @AllArgsConstructor
    @Builder
    @Data
    @ToString
    public static class Recipient{
        private  String msisdn;
    }
}
