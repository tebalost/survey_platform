package com.sbs.zuatech.mhealth.api.dto;

import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.*;

import java.time.LocalDate;
import java.time.LocalTime;
import java.util.Date;

@NoArgsConstructor
@AllArgsConstructor
@Builder
@ToString
@Data
public class ParticipantReportResponse {
    private String authorityCode;
    private String msisdn;
    private String status;
    private String type;
    private String typeId;
    private String typeQuestion;
    private String typeQuestionId;
    private String typeAnswer;
    private String typeAnswerId;
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd")
    private Date answerDate;
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "HH:mm:ss")
    private Date answerTime;
}
