package com.sbs.zuatech.mhealth.persistance.repository;

import com.sbs.zuatech.mhealth.persistance.entity.MHealthFile;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import javax.transaction.Transactional;
import java.util.List;

@Repository
public interface MHealthFileRepository extends CrudRepository<MHealthFile, Long> {

    @Transactional
    @Query(value = "select count(authority),  authority  from mhealth_file  group by authority", nativeQuery = true)
    List<Object[]> nativeCountAuthorities();


    @Query(value = "select distinct (type_id), type_name from  mhealth_file group by type_id, type_name", nativeQuery = true)
    List<Object[]> nativeCountUniqueTypes();


}
