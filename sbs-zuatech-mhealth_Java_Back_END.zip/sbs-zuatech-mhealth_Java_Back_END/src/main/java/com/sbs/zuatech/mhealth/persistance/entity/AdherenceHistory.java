package com.sbs.zuatech.mhealth.persistance.entity;

import lombok.*;

import javax.persistence.*;
import java.util.Date;

@Entity
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class AdherenceHistory {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Setter(AccessLevel.NONE)
    private long adherenceHistoryId;
    private long adherenceId;
    @Enumerated(EnumType.STRING)
    private MessageStatus messageStatus;
    private String authorityCode;
    private String userId;
    private String msisdn;
    private String correlationId;
    private String answer;
    private String text;
    private String startDate;
    private String endDate;
    private int type;
    @Temporal(TemporalType.TIMESTAMP)
    @Setter(AccessLevel.NONE)
    private Date createdAt;
    @Temporal(TemporalType.TIMESTAMP)
    @Setter(AccessLevel.NONE)
    private Date updatedAt;

    @Column(name = "ADHERENCE_PAYLOAD_JSON", length = 1024)
    private String adherencePayloadJson;

    @Column(name = "ADHERENCE_PAYLOAD_XML", length = 1024)
    private String adherencePayloadXml;

    @PrePersist
    public void updateDates() {
        this.createdAt = new Date();
        this.updatedAt = new Date();
    }

    @PreUpdate
    public void updatedDate() {
        this.updatedAt = new Date();
    }
}
