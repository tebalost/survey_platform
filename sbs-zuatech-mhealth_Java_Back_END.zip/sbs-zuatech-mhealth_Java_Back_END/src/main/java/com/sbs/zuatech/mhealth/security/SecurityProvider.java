package com.sbs.zuatech.mhealth.security;


import com.sbs.zuatech.mhealth.persistance.entity.BusinessUser;
import com.sbs.zuatech.mhealth.persistance.repository.BusinessUserRepository;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.AuthenticationProvider;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.web.authentication.WebAuthenticationDetails;
import org.springframework.security.web.authentication.session.SessionAuthenticationException;
import org.springframework.stereotype.Component;
import org.springframework.util.ObjectUtils;

import java.util.ArrayList;
import java.util.List;

@Component
@Slf4j
public class SecurityProvider implements AuthenticationProvider {

    private BusinessUserRepository businessUserRepository;

    @Autowired
    public SecurityProvider(BusinessUserRepository businessUserRepository) {
        this.businessUserRepository = businessUserRepository;
    }

    @Override
    public Authentication authenticate(Authentication authentication)
            throws AuthenticationException {
        final String userName = authentication.getName();
        final String password = authentication.getCredentials().toString();

        if(userName==null){
            throw new SessionAuthenticationException("Either Username or Password is invalid");
        }

        String role;
        //See  if the user is there and authenticate them
        final BusinessUser user = findUserToBeAuthenticated(userName);

        if (ObjectUtils.isEmpty(user.getRole())) {
            throw new SessionAuthenticationException("Please contact Admin to finalise your registration");
        }
        final List<GrantedAuthority> grantedAuths = new ArrayList<>();

        grantedAuths.add(new SimpleGrantedAuthority(user.getRole().name()));

        final UserDetails principal = new org.springframework.security.core.userdetails.User(userName, password, grantedAuths);
        final Authentication auth = new UsernamePasswordAuthenticationToken(principal, password, grantedAuths);


        final Object details = auth.getDetails();
        if (details instanceof WebAuthenticationDetails) {
        }
        return auth;
    }

    @Override
    public boolean supports(Class<?> aClass) {
        boolean clazzSupports = aClass.equals(UsernamePasswordAuthenticationToken.class);

        return clazzSupports;
    }

    private BusinessUser findUserToBeAuthenticated(final String userName)
            throws AuthenticationException {
        return businessUserRepository.findFirstByEmail(userName).orElseThrow(() -> new SessionAuthenticationException("User not registered as yet"));
    }

}

//SecurityContextHolder
//        return new AuthenticationToken(userName, password, new ArrayList<>());
//        https://www.javadevjournal.com/spring/securing-a-restful-web-service-with-spring-security/