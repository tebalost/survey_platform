package com.sbs.zuatech.mhealth.api.dto;

import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;

@NoArgsConstructor
@AllArgsConstructor
//@XmlRootElement(name = "ussdAppRequest")
public abstract class USSDAppRequest {
    protected String msisdn;
    protected String sessionId;
    protected String network;
    protected String type;
}
