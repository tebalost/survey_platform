package com.sbs.zuatech.mhealth.service;

import com.sbs.zuatech.mhealth.api.dto.ParticipantAuthorityResponse;
import com.sbs.zuatech.mhealth.api.dto.reports.DashboardTopMenuStats;
import com.sbs.zuatech.mhealth.api.dto.reports.TypeStats;
import com.sbs.zuatech.mhealth.exception.InvalidInput;
import com.sbs.zuatech.mhealth.exception.RecordNotFoundInDataBase;
import com.sbs.zuatech.mhealth.persistance.entity.MessageStatus;
import com.sbs.zuatech.mhealth.persistance.repository.AdherenceRepository;
import com.sbs.zuatech.mhealth.persistance.repository.SurveyCacheHistoryRepository;
import com.sbs.zuatech.mhealth.persistance.repository.SurveyCacheRepository;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;

@Slf4j
@Service
public class ReportServiceImpl implements ReportService {

    final private SurveyCacheRepository surveyCacheRepository;
    final private AdherenceRepository adherenceRepository;
    final private SurveyCacheHistoryRepository surveyCacheHistoryRepository;

    @Autowired
    public ReportServiceImpl(SurveyCacheRepository surveyCacheRepository, AdherenceRepository adherenceRepository,
                             SurveyCacheHistoryRepository surveyCacheHistoryRepository) {
        this.surveyCacheRepository = surveyCacheRepository;
        this.adherenceRepository = adherenceRepository;
        this.surveyCacheHistoryRepository = surveyCacheHistoryRepository;
    }

    @Override
    public DashboardTopMenuStats getMenuStats(String authorityCode, String roleCode) throws InvalidInput {

        try {
            if (!StringUtils.hasLength(authorityCode) || !StringUtils.hasLength(roleCode))
                throw new InvalidInput("Either client code or role should not be empty");

            long totalActiveSurveys,
                    totalActiveAdherences,
                    totalSentSMS,
                    totalUssdMessages;
            if (ROLE_SUPER.contains(roleCode)) {
                totalActiveSurveys = surveyCacheRepository.count();
                totalActiveAdherences = adherenceRepository.count();
                totalUssdMessages = surveyCacheHistoryRepository.count();
            } else {
                totalActiveSurveys = surveyCacheRepository.countAllByAuthorityCode(authorityCode);
                totalActiveAdherences = adherenceRepository.countAllByAuthorityCode(authorityCode);
                totalUssdMessages = surveyCacheHistoryRepository.countAllByAuthorityCode(authorityCode);
            }
            totalSentSMS = totalActiveAdherences + totalActiveSurveys;

            return DashboardTopMenuStats.builder()
                    .totalActiveAdherences(totalActiveAdherences)
                    .totalActiveSurveys(totalActiveSurveys)
                    .totalSentSMS(totalSentSMS)
                    .totalUssdMessages(totalUssdMessages)
                    .build();
        } catch (Exception e) {
            log.error("there is error when trying to execute the query" + e.getMessage());
            throw new InvalidInput("there is error when trying to execute the query" + e.getMessage());
        }
    }

    @Override
    public DashboardTopMenuStats getMenuStats() throws InvalidInput {
        return null;
    }

    @Override
    public List<TypeStats> getSurveyStates(String authorityCode, String roleCode) throws InvalidInput, RecordNotFoundInDataBase {

        if (!StringUtils.hasLength(authorityCode) || !StringUtils.hasLength(roleCode))
            throw new InvalidInput("Either client code or role should not be empty");

        List<TypeStats> typeStats = new ArrayList<>();
        int incompleteSurveys = 0, failedSurveys = 0, dispatchedSurveys = 0, totalCount = 0, completedSurveys = 0;
        String surveyName = "";

        if (ROLE_SUPER.contains(roleCode)) {
            for (final Object[] ob : surveyCacheRepository.allUniqueSurveys()) {
                final String surveyId = (ob[0] != null) ? ob[0].toString() : "";
                surveyName = (ob[1] != null) ? ob[1].toString() : "";

                incompleteSurveys = surveyCacheRepository.countAllByMessageStatusAndSurveyId(MessageStatus.INCOMPLETE, surveyId);
                failedSurveys = surveyCacheRepository.countAllByMessageStatusAndSurveyId(MessageStatus.ABORTED, surveyId);
                dispatchedSurveys = surveyCacheRepository.countAllByMessageStatusAndSurveyId(MessageStatus.DISPATCHED, surveyId);
                completedSurveys = surveyCacheRepository.countAllByMessageStatusAndSurveyId(MessageStatus.COMPLETED, surveyId);

                totalCount = incompleteSurveys + failedSurveys + dispatchedSurveys;

                typeStats.add(TypeStats.builder().name(surveyName).total(totalCount)
                        .stateCount(TypeStats.StateCount.builder()
                                .failed(failedSurveys)
                                .notTaken(dispatchedSurveys + incompleteSurveys)
                                .taken(completedSurveys)
                                .build())
                        .build());
            }
        } else {
            for (final Object[] ob : surveyCacheRepository.allAuthorityUniqueSurveys(authorityCode)) {
                final String surveyId = (ob[0] != null) ? ob[0].toString() : "";
                surveyName = (ob[1] != null) ? ob[1].toString() : "";

                incompleteSurveys = surveyCacheRepository.countAllByMessageStatusAndSurveyIdAndAuthorityCode(MessageStatus.INCOMPLETE, surveyId, authorityCode);
                failedSurveys = surveyCacheRepository.countAllByMessageStatusAndSurveyIdAndAuthorityCode(MessageStatus.ABORTED, surveyId, authorityCode);
                dispatchedSurveys = surveyCacheRepository.countAllByMessageStatusAndSurveyIdAndAuthorityCode(MessageStatus.DISPATCHED, surveyId, authorityCode);
                completedSurveys = surveyCacheRepository.countAllByMessageStatusAndSurveyIdAndAuthorityCode(MessageStatus.COMPLETED, surveyId, authorityCode);

                totalCount = incompleteSurveys + failedSurveys + dispatchedSurveys;

                typeStats.add(TypeStats.builder().name(surveyName).total(totalCount)
                        .stateCount(TypeStats.StateCount.builder()
                                .failed(failedSurveys)
                                .notTaken(dispatchedSurveys + incompleteSurveys)
                                .taken(completedSurveys)
                                .build())
                        .build());
            }

        }
        return typeStats;
    }

    @Override
    public List<TypeStats> getAdherenceStates(String authorityCode, String roleCode) throws InvalidInput, RecordNotFoundInDataBase {

        if (!StringUtils.hasLength(authorityCode) || !StringUtils.hasLength(roleCode))
            throw new InvalidInput("Either client code or role should not be empty");

        List<TypeStats> typeStats = new ArrayList<>();
        List<Object[]> objects = new ArrayList<>();

        try {
            objects = (ROLE_SUPER.contains(roleCode))?adherenceRepository.allUniqueAdherence(): adherenceRepository.allAuthorityAdherence(authorityCode);
            objects.forEach(ob -> {
                final BigInteger count = (BigInteger) ob[0];
                final String correlationId = (ob[1] != null) ? ob[1].toString() : "";
                typeStats.add(TypeStats.builder().name("Drug - " + correlationId.substring(0, 2)).total(count.intValue())
                        .stateCount(TypeStats.StateCount.builder()
                                .failed(0)
                                .notTaken(0)
                                .taken(0)
                                .build())
                        .build());
            });
            return typeStats;
        } catch (Exception e) {
            log.error("Error : could not get records from the DB" + e.getMessage());
            throw new RecordNotFoundInDataBase("Error : could not get records from the DB" + e.getMessage());
        }

    }
}
