package com.sbs.zuatech.mhealth.cache;

import com.sbs.zuatech.mhealth.api.dto.menu.SurveyMenu;
import com.sbs.zuatech.mhealth.api.dto.webhook.WebHookSurveyRequest;
import com.sbs.zuatech.mhealth.integration.model.SurveyParticipant;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;

@Component
@Data
public class USSDCacheClient {

    private List<USSDCacheDto> ussdCacheDtos = new ArrayList<>();

//    @Cacheable
//    public List<USSDCacheDto> getUssdCacheDtos() {
//        return ussdCacheDtos;
//    }

    private WebHookSurveyRequest hookRequest;
    private ParticipantSurveyDetails participantSurveyDetails;
    private SurveyMenu surveyMenu;

    //    @Cacheable(key="#surveyId")

    @Cacheable("hookRequest")
    public WebHookSurveyRequest getHookRequest() {
        return hookRequest;
    }

    @Cacheable("participantSurveyDetails")
    public ParticipantSurveyDetails getParticipantSurveyDetails() {
        return participantSurveyDetails;
    }

    @Cacheable("surveyMenu")
    public SurveyMenu getSurveyMenu() {
        return surveyMenu;
    }

    @Data
    @Builder
    @AllArgsConstructor
    @NoArgsConstructor
    public static class ParticipantSurveyDetails {
        private List<SurveyParticipant> surveyParticipants = new ArrayList<>();
        private String surveyId;

    }


}
