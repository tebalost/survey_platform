package com.sbs.zuatech.mhealth.service;

import com.sbs.zuatech.mhealth.api.dto.ParticipantAuthorityResponse;
import com.sbs.zuatech.mhealth.api.dto.ParticipantReportResponse;
import com.sbs.zuatech.mhealth.api.dto.ParticipantResponse;
import com.sbs.zuatech.mhealth.api.dto.webhook.TempCustomer;
import com.sbs.zuatech.mhealth.exception.InvalidInput;
import com.sbs.zuatech.mhealth.exception.RecordNotFoundInDataBase;
import com.sbs.zuatech.mhealth.persistance.entity.Adherence;
import com.sbs.zuatech.mhealth.persistance.entity.SurveyCacheHistory;
import com.sbs.zuatech.mhealth.persistance.repository.AdherenceRepository;
import com.sbs.zuatech.mhealth.persistance.repository.MHealthFileRepository;
import com.sbs.zuatech.mhealth.persistance.repository.SurveyCacheHistoryRepository;
import com.sbs.zuatech.mhealth.persistance.repository.SurveyCacheRepository;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.*;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.atomic.AtomicReference;

@Slf4j
@Service
public class ParticipantServiceImpl implements ParticipantService{

    private MHealthFileRepository mHealthFileRepository;
    private AdherenceRepository adherenceRepository;
    private SurveyCacheRepository surveyCacheRepository;
    private SurveyCacheHistoryRepository surveyCacheHistoryRepository;


     @Autowired
    public ParticipantServiceImpl(MHealthFileRepository mHealthFileRepository,
                                  AdherenceRepository adherenceRepository,
                                  SurveyCacheRepository surveyCacheRepository,
                                  SurveyCacheHistoryRepository surveyCacheHistoryRepository){
        this.mHealthFileRepository = mHealthFileRepository;
        this.adherenceRepository = adherenceRepository;
        this.surveyCacheRepository= surveyCacheRepository;
         this.surveyCacheHistoryRepository=surveyCacheHistoryRepository;

    }

    @Override
    public List<ParticipantAuthorityResponse> listAllAuthorities() throws InvalidInput, RecordNotFoundInDataBase {
        List<ParticipantAuthorityResponse> authorityResponses = new ArrayList<>();

        for (final Object[] ob : mHealthFileRepository.nativeCountAuthorities()) {
            final BigInteger count = (BigInteger) ob[0];
            final String name = (ob[1] != null) ? ob[1].toString() : "";

            authorityResponses.add(ParticipantAuthorityResponse.builder()
                    .authorityCode(name)
                    .authorityName(name)
                    .participantCount(count.intValue()).build());
        }
        return authorityResponses;
    }

    @Override
    public List<ParticipantReportResponse> listAllAuthorityParticipantReports() throws InvalidInput, RecordNotFoundInDataBase {
        return null;
    }

    @Override
    public List<ParticipantResponse> listAllAuthorityParticipants(String authorityCode)
            throws InvalidInput, RecordNotFoundInDataBase {
        List<ParticipantResponse> responses = new ArrayList<>();
        responses.add(ParticipantResponse.builder()
                .msisdn("27837747118")
                .status("Active")
                .surveyCount(14)
                .adherenceCount(10)
                .build());
        responses.add(ParticipantResponse.builder()
                .msisdn("27837747118")
                .status("Active")
                .surveyCount(9)
                .adherenceCount(0)
                .build());
        return responses;
    }

    @Override
    public List<ParticipantReportResponse> listAuthorityParticipantReports(String authorityCode, String roleCode)
            throws InvalidInput, RecordNotFoundInDataBase {

        validateInput( roleCode , authorityCode);

        List<ParticipantReportResponse> responses = new ArrayList<>();

        Iterable<Adherence> adherences;
        Iterable<SurveyCacheHistory> surveyCacheHistories;

         if (ROLE_SUPER.contains(roleCode)) {
             adherences = adherenceRepository.findAll();
             surveyCacheHistories = surveyCacheHistoryRepository.findAll();
         }else {
             adherences = adherenceRepository.findAllByAuthorityCode(authorityCode);
             surveyCacheHistories = surveyCacheHistoryRepository.findAllByAuthorityCode(authorityCode);
         }

        return getResponse( adherences, surveyCacheHistories);
    }

    @Override
    public List<ParticipantReportResponse> getAllAuthorityParticipantReports(Integer pageNo, Integer pageSize, String sortBy,
                                                                             String roleCode ,String authorityCode)
            throws InvalidInput, RecordNotFoundInDataBase {
        validateInput( roleCode , authorityCode);

        Pageable paging = PageRequest.of(pageNo, pageSize, Sort.by(sortBy).descending());

        List<ParticipantReportResponse> responses = new ArrayList<>();

        Iterable<Adherence> adherences;
        Iterable<SurveyCacheHistory> surveyCacheHistories;

        if (ROLE_SUPER.contains(roleCode)) {
            Page<Adherence> pagedAdherences = adherenceRepository.findAll(paging);
            Page<SurveyCacheHistory> pagedSurveyCacheHistories = surveyCacheHistoryRepository.findAll(paging);

            adherences = pagedAdherences.getContent();
            surveyCacheHistories = pagedSurveyCacheHistories.getContent();
        }else {
            Slice<Adherence> slicedResultAdherences = adherenceRepository.findAllByAuthorityCode(authorityCode, paging);
            Slice<SurveyCacheHistory> slicedResultSurveyCacheHistories = surveyCacheHistoryRepository.findAllByAuthorityCode(authorityCode, paging);

            adherences = slicedResultAdherences.getContent();
            surveyCacheHistories = slicedResultSurveyCacheHistories.getContent();
        }

        return getResponse( adherences, surveyCacheHistories);
    }

    @Override
    public Long countAuthorityParticipantReportRows(String roleCode, String authorityCode)
            throws InvalidInput, RecordNotFoundInDataBase {
        validateInput( roleCode , authorityCode);
         AtomicReference<Long> totalCount = new AtomicReference<>(Long.valueOf(0));
        if (ROLE_SUPER.contains(roleCode)) {
           totalCount.set(
                   Long.sum(adherenceRepository.count(),surveyCacheHistoryRepository.count()));
        }else {
            totalCount.set(Long.valueOf(adherenceRepository.countAllByAuthorityCode(authorityCode)
                    + surveyCacheHistoryRepository.countAllByAuthorityCode(authorityCode)));
        }
        log.info("total record retrieved -> {}", totalCount.get());
        return totalCount.get();
    }



    private void validateInput(String roleCode ,String authorityCode) throws InvalidInput{
        if (!StringUtils.hasLength(authorityCode) || !StringUtils.hasLength(roleCode))
            throw new InvalidInput("Either client code or role should not be empty");
    }

   private  List<ParticipantReportResponse> getResponse( Iterable<Adherence> adherences,
            Iterable<SurveyCacheHistory> surveyCacheHistories){
        List<ParticipantReportResponse> responses = new ArrayList<>();
        adherences.forEach(
                adherence -> {
                    responses.add(ParticipantReportResponse.builder()
                            .type("ADHERENCE")
                            .typeId("wewrqw-qe32eqwewq-qweqewqe")
                            .msisdn(adherence.getMsisdn())
                            .typeQuestion(adherence.getText())
                            .typeQuestionId("wewrqw-qe32eqwewq-qeeere")
                            .status(adherence.getMessageStatus()!=null? adherence.getMessageStatus().name():"")
                            .typeAnswer(adherence.getAnswer())
                            .typeAnswerId("")
                            .authorityCode("")
                            .answerDate(adherence.getUpdatedAt())
                            .answerTime(adherence.getUpdatedAt())
                            .build());
                }
        );

        // FIXME implement correctly (// align the question and answer)
        surveyCacheHistories.forEach(
                surveyCache -> {
                    responses.add(ParticipantReportResponse.builder()
                            .type("SURVEY")
                            .typeId(surveyCache.getSurveyId())
                            .msisdn(surveyCache.getMsisdn())
                            .typeQuestion(surveyCache.getQuestion())
                            .typeQuestionId(surveyCache.getQuestionId())
                            .status(surveyCache.getMessageStatus().name())
                            .typeAnswer(surveyCache.getAnswer())
                            .typeAnswerId(surveyCache.getAnswerId())
                            .authorityCode(surveyCache.getAuthorityCode())
                            .answerDate(surveyCache.getUpdatedAt())
                            .answerTime(surveyCache.getUpdatedAt())
                            .build());
                }
        );
        return responses;
    }

    private  List<TempCustomer> getMockResponse( Iterable<Adherence> adherences,
                                                          Iterable<SurveyCacheHistory> surveyCacheHistories){
        List<TempCustomer> responses = new ArrayList<>();
        adherences.forEach(
                adherence -> {
                    responses.add(
                            TempCustomer.builder()
                                    .activity("Activity"+adherence.getAdherenceId())
                                    .representative(TempCustomer.Representative.builder()
                                            .name(adherence.getMsisdn())
                                            .image(adherence.getMessageStatus().name())
                                            .build())
                                    .country(TempCustomer.Country.builder()
                                            .code(adherence.getMsisdn())
                                            .name(adherence.getMsisdn())
                                            .build())
                                    .company(adherence.getText())
                                    .name(adherence.getUserId())
                                    .build()
                    );
                }
        );

        // FIXME implement correctly (// align the question and answer)
        surveyCacheHistories.forEach(
                surveyCache -> {
                    responses.add(
                            TempCustomer.builder()
                                    .activity("Activity"+surveyCache.getSurveyId())
                                    .representative(TempCustomer.Representative.builder()
                                            .name(surveyCache.getMsisdn())
                                            .image(surveyCache.getMessageStatus().name())
                                            .build())
                                    .country(TempCustomer.Country.builder()
                                            .code(surveyCache.getMsisdn())
                                            .name(surveyCache.getMsisdn())
                                            .build())
                                    .company(surveyCache.getMsisdn())
                                    .name(surveyCache.getQuestionId())
                                    .build()
                    );
                }
        );
        return responses;
    }

    @Override
    public List<TempCustomer> getAllTempCustomers(Integer pageNo, Integer pageSize, String sortBy, String roleCode, String authorityCode)
            throws InvalidInput, RecordNotFoundInDataBase{
            validateInput( roleCode , authorityCode);

            Pageable paging = PageRequest.of(pageNo, pageSize, Sort.by(sortBy).descending());

            List<TempCustomer> responses = new ArrayList<>();

            Iterable<Adherence> adherences;
            Iterable<SurveyCacheHistory> surveyCacheHistories;

            if (ROLE_SUPER.contains(roleCode)) {
                Page<Adherence> pagedAdherences = adherenceRepository.findAll(paging);
                Page<SurveyCacheHistory> pagedSurveyCacheHistories = surveyCacheHistoryRepository.findAll(paging);

                adherences = pagedAdherences.getContent();
                surveyCacheHistories = pagedSurveyCacheHistories.getContent();
            }else {
                Slice<Adherence> slicedResultAdherences = adherenceRepository.findAllByAuthorityCode(authorityCode, paging);
                Slice<SurveyCacheHistory> slicedResultSurveyCacheHistories = surveyCacheHistoryRepository.findAllByAuthorityCode(authorityCode, paging);

                adherences = slicedResultAdherences.getContent();
                surveyCacheHistories = slicedResultSurveyCacheHistories.getContent();
            }

            return getMockResponse( adherences, surveyCacheHistories);
    }
}
