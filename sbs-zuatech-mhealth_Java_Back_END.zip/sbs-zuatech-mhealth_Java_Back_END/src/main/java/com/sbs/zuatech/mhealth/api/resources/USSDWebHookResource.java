package com.sbs.zuatech.mhealth.api.resources;

import com.sbs.zuatech.mhealth.exception.InvalidInput;
import com.sbs.zuatech.mhealth.service.USSDService;
import com.sbs.zuatech.mhealth.service.WebHookService;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.util.UriComponentsBuilder;
import reactor.core.publisher.Mono;

import javax.servlet.http.HttpServletRequest;

@RestController
@RequestMapping(path = "/api")
@Data
@Slf4j
public class USSDWebHookResource {
    public static String TAG_MHEALTH_WEBHOOK = "mHealth Survey";

    private WebHookService webHookService;

    private USSDService ussdService;

    @Autowired
    public USSDWebHookResource(WebHookService webHookService,
                               USSDService ussdService) {

        this.webHookService = webHookService;
        this.ussdService = ussdService;
    }

    @GetMapping(path = "/ping-ussd")
    public String ping() {
        return "pong";
    }

    @PostMapping(path = "/execute-ussd")
//    @ApiOperation(value = "Initiates the USSD from the client", tags = "ussd")
    public Mono<ResponseEntity<String>> createPost(HttpServletRequest request,
                                                   UriComponentsBuilder uriComponentsBuilder) throws InvalidInput {
        String content = request.getParameter("xml");


        if (content.contains("<type>initial</type>")) {
            content = content.replace("ussdAppRequest", "ussdAppRequestInit");
        } else if (content.contains("<type>action</type>")) {
            content = content.replace("ussdAppRequest", "ussdAppRequestAction");
        }

        log.info(String.format("Our XML content is ->\n\n %s\n\n", content));

        String ussdAppResponseInit = ussdService.processSurveyNotificationMarshalled(content);

        log.info(String.format("Their XML content is ->\n\n %s\n\n", ussdAppResponseInit));

        return Mono.just(ResponseEntity.ok()
                .header("Content-SurveyType", "application/x-www-form-urlencoded")
                .body(ussdAppResponseInit));
    }


    @PostMapping(path = "/execute-adherence")
//    @ApiOperation(value = "Accepts the SMS from the client", tags = "ussd")
    public Mono<ResponseEntity<String>> createPostAdherence(HttpServletRequest request,
                                                   UriComponentsBuilder uriComponentsBuilder) throws InvalidInput {
        String content = request.getParameter("xml");

        if(content == null){
            content =  request.getParameter("XML");
        }

        if (content.contains("<responseType>error</responseType>")) {
            content = content.replace("gviSmsResponse", "gviSmsResponseError");
        } else if (content.contains("<responseType>receipt</responseType>")) {
            content = content.replace("gviSmsResponse", "gviSmsResponseReceipt");
        }else if (content.contains("<responseType>reply</responseType>")) {
            content = content.replace("gviSmsResponse", "gviSmsResponseReply");
        }

        log.info(String.format("Our XML content is ->\n\n %s\n\n", content));

        String response =ussdService.processAdherentNotification(content);

        return Mono.just(ResponseEntity.ok()
                .header("Content-SurveyType", "application/x-www-form-urlencoded")
                .body(response));
    }
}
