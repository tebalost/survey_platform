package com.sbs.zuatech.mhealth.api.resources;

import com.sbs.zuatech.mhealth.exception.InvalidInput;
import com.sbs.zuatech.mhealth.exception.RecordNotFoundInDataBase;
import com.sbs.zuatech.mhealth.persistance.entity.BusinessUser;
import com.sbs.zuatech.mhealth.service.BusinessUserService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.ArraySchema;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import reactor.core.publisher.Mono;

@RestController
@RequestMapping(path = "/api")
@Tag(name = "Business User", description = "the Business User API")
@Data
@Slf4j
public class BusinessUserResource {
 final private BusinessUserService businessUserService;

    @Autowired
    public BusinessUserResource(BusinessUserService businessUserService) {
        this.businessUserService = businessUserService;
    }

    @PostMapping(path = "/create-update-user")
    @Operation(summary = "Create a Business User", description = "Create a Business User", tags = { "business user" })
    @ApiResponses(value = {
        @ApiResponse(responseCode = "200", description = "successful operation",
                content = @Content(array = @ArraySchema(schema = @Schema(implementation = BusinessUser.class)))) })
    public Mono<ResponseEntity<BusinessUser>> createUpdateUser(
            @Parameter(description="Contact's address to update.",
                    required=true, schema=@Schema(implementation = BusinessUser.class))
            @RequestBody BusinessUser request)
            throws InvalidInput, RecordNotFoundInDataBase {
        return Mono.just(ResponseEntity.ok()
                .header("Content-SurveyType", "application/json")
                .body(businessUserService.createUpdateUser(request)));
    }

    @GetMapping(path = "business-user-login/{email}")
//    @ApiOperation(value = "business-user-login",response = BusinessUser.class , tags = "Business User")
    public  Mono<ResponseEntity<BusinessUser>>  getBusinessUserByEmail( @PathVariable("email")  String email)
            throws InvalidInput, RecordNotFoundInDataBase{
        return Mono.just(ResponseEntity.ok()
                .body(businessUserService.findByEmail(email)));
    }

    @GetMapping(path = "list-business-users")
//    @ApiOperation(value = "list-business-users", response = Iterable.class, tags = "Business User")
    public  Mono<ResponseEntity<Iterable<BusinessUser>>>  listBusinessUsers()
            throws InvalidInput, RecordNotFoundInDataBase{
        return Mono.just(ResponseEntity.ok()
                .body(businessUserService.findAll()));
    }

    @GetMapping(path = "list-authority-business-users/{authority-code}")
//    @ApiOperation(value = "list-authority-business-users", response = Iterable.class, tags = "Business User")
    public  Mono<ResponseEntity<Iterable<BusinessUser>>>  listBusinessUsers(@PathVariable("authority-code")  String authorityCode)
            throws InvalidInput, RecordNotFoundInDataBase{
        return Mono.just(ResponseEntity.ok()
                .body(businessUserService.findBySystemClient(authorityCode)));
    }
}
