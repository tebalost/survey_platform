package com.sbs.zuatech.mhealth.persistance.entity;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.*;

import javax.persistence.*;

@Entity
@Table
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class USSDSessionReport {

    @JsonInclude(JsonInclude.Include.NON_EMPTY)
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Setter(AccessLevel.NONE)
    private long ussdSessionReportId;

    @JsonProperty(value = "MSISDN")
    @Column(name = "msisdn_participant")
    private String msisdn;

    @JsonProperty(value = "NETWORK")
    private String network;

    @JsonProperty(value = "AFFILIATE_CODE")
    private String affiliateCode;

    @JsonProperty(value = "USSD_STRING")
    private String ussdString;

    @JsonProperty(value = "CAMPAIGN")
    private String campaign;

    @JsonProperty(value = "SENT_DATE")

    private String sentDate;

    @JsonProperty(value = "LAST_STATE")
    private String lastState;

    @JsonProperty(value = "STATUS")
    private String status;

    @JsonProperty(value = "DURATION")
    private String duration;

    @JsonProperty(value = "CLICKS_NR")
    private String clicksNr;

    @JsonProperty(value = "20_Second_Interval")
    private String interval20Sec;
}
