package com.sbs.zuatech.mhealth.api.dto;

import lombok.*;

import javax.xml.bind.annotation.XmlRootElement;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
@ToString(doNotUseGetters = true)
@XmlRootElement(name = "ussdAppRequestAction")
public class USSDAppRequestAction {
    Fields Fields;
    private String msisdn;
    private String sessionId;
    private String name;
    private String network;
    private String type;

    @Data
    @Builder
    @AllArgsConstructor
    @NoArgsConstructor
    public static class Fields {
        Field Field;

        @Data
        @Builder
        @AllArgsConstructor
        @NoArgsConstructor
        public static class Field {
            private String name;
            private String value;
        }

    }
}





