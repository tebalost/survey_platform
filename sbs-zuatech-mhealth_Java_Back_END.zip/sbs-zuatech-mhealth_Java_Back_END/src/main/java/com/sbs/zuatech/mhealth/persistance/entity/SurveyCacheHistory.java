package com.sbs.zuatech.mhealth.persistance.entity;

import lombok.*;

import javax.persistence.*;
import java.util.Date;

@Entity
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class SurveyCacheHistory {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Setter(AccessLevel.NONE)
    private long surveyCacheHistoryId;
    private long surveyCacheId;
    private String surveyId;
    private String surveyName;
    private String finishDate;
    private String surveyUserId;
    private String authorityCode;
    private String answerId;
    private String msisdn;
    private String answer;
    private String question;
    private String questionId;
    private String network;
    private String surveyTakenQuestionId;
    @Enumerated(EnumType.STRING)
    private MessageStatus messageStatus;
    @Column(name = "SURVEY_PAYLOAD", length = 1024)
    private String surveyPayloadJson;
    @Column(name = "USSD_PAYLOAD", length = 1024)
    private String ussdPayloadXml;

    @Temporal(TemporalType.TIMESTAMP)
    private Date createdAt;
    @Temporal(TemporalType.TIMESTAMP)
    private Date updatedAt;
}
