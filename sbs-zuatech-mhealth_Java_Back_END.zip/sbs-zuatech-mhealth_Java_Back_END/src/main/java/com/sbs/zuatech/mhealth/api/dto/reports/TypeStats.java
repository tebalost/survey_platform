package com.sbs.zuatech.mhealth.api.dto.reports;

import lombok.*;

@NoArgsConstructor
@AllArgsConstructor
@Builder
@ToString
@Data
public class TypeStats {
    private String name;
    private int total;
    private StateCount stateCount;

    @NoArgsConstructor
    @AllArgsConstructor
    @Builder
    @ToString
    @Data
    public static class StateCount {
        private int taken;
        private int failed;
        private int notTaken;
    }
}
