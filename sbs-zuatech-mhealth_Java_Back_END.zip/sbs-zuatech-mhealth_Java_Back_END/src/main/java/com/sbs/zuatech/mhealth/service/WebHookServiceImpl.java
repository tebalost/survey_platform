package com.sbs.zuatech.mhealth.service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.sbs.zuatech.mhealth.api.dto.menu.GviSmsMessageSbsCustom;
import com.sbs.zuatech.mhealth.api.dto.menu.ObjectFactory;
import com.sbs.zuatech.mhealth.api.dto.menu.Upload;
import com.sbs.zuatech.mhealth.api.dto.menu.UploadResponse;
import com.sbs.zuatech.mhealth.api.dto.webhook.WebHookAdherenceRequest;
import com.sbs.zuatech.mhealth.api.dto.webhook.WebHookSurveyRequest;
import com.sbs.zuatech.mhealth.config.properties.GrapevineSmsProperties;
import com.sbs.zuatech.mhealth.exception.InvalidInput;
import com.sbs.zuatech.mhealth.integration.MHealthClient;
import com.sbs.zuatech.mhealth.integration.model.SurveyParticipant;
import com.sbs.zuatech.mhealth.integration.soap.SOAPConnector;
import com.sbs.zuatech.mhealth.persistance.entity.*;
import com.sbs.zuatech.mhealth.persistance.repository.AdherenceHistoryRepository;
import com.sbs.zuatech.mhealth.persistance.repository.AdherenceRepository;
import com.sbs.zuatech.mhealth.persistance.repository.SurveyCacheHistoryRepository;
import com.sbs.zuatech.mhealth.persistance.repository.SurveyCacheRepository;
import com.sbs.zuatech.mhealth.util.JsonUtil;
import com.sun.xml.bind.marshaller.NamespacePrefixMapper;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBElement;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;
import java.io.StringWriter;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

@Service
@Slf4j
public class WebHookServiceImpl implements WebHookService {

    public static final String HOUR = "23";
    public static String SURVEY_MSG = "";
    public static String ADHERENCE_MSG = "";

    private MHealthClient mHealthClient;
    private SurveyCacheRepository repository;
    private SurveyCacheHistoryRepository surveyCacheHistory;

    private SOAPConnector soapConnector;

    private GrapevineSmsProperties grapevineSmsProperties;

    private AdherenceRepository adherenceRepository;

    private AdherenceHistoryRepository adherenceHistoryRepository;

    @Autowired
    public WebHookServiceImpl(MHealthClient mHealthClient,
                              SOAPConnector soapConnector,
                              SurveyCacheRepository repository,
                              SurveyCacheHistoryRepository surveyCacheHistory,
                              GrapevineSmsProperties grapevineSmsProperties,
                              AdherenceRepository adherenceRepository,
                              AdherenceHistoryRepository adherenceHistoryRepository) {
        this.soapConnector = soapConnector;
        this.mHealthClient = mHealthClient;
        this.repository = repository;
        this.surveyCacheHistory = surveyCacheHistory;
        this.grapevineSmsProperties = grapevineSmsProperties;
        this.adherenceRepository = adherenceRepository;
        this.adherenceHistoryRepository = adherenceHistoryRepository;
    }

    @Override
    public String processSurveyNotification(WebHookSurveyRequest hookRequest) throws InvalidInput {

        SURVEY_MSG = "Dear user!  A new survey " + hookRequest.getSurveyName() + " is published.\n" +
                "Please dial " + grapevineSmsProperties.getDialingCode() +
                "  Survey closure date : " + hookRequest.getSurveyClosure();

        List<SurveyParticipant> surveyParticipants;
        try {
            surveyParticipants = mHealthClient.findSurveyParticipants(hookRequest.getSurveyId());
            log.debug("The participants of the survey are=  ==> {}", surveyParticipants);

            List<SurveyCache> surveyCacheList = new ArrayList<>();

            List<String> msisdns = new ArrayList<>();
            surveyParticipants.forEach(
                    surveyParticipant -> {
                        msisdns.add(surveyParticipant.getPhone());
                        surveyCacheList.add(SurveyCache.builder()
                                .surveyId(hookRequest.getSurveyId())
                                .surveyName(hookRequest.getSurveyName())
                                .finishDate(hookRequest.getSurveyClosure())
                                .msisdn(surveyParticipant.getPhone())
                                .surveyUserId(surveyParticipant.getId())
                                .messageStatus(MessageStatus.DISPATCHED)
                                .build());
                    }
            );
            repository.saveAll(surveyCacheList);

            //Update CACHE
            List<SurveyCacheHistory> surveyCacheHistories = surveyCacheList.stream()
                    .map(SurveyCache::getSurveyCacheHistory)
                    .collect(Collectors.toList());
            surveyCacheHistory.saveAll(surveyCacheHistories);

            LocalDateTime currentDateTime = LocalDateTime.now();
            DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss");
            sendSms(currentDateTime.format(formatter), currentDateTime.format(formatter), SURVEY_MSG, msisdns);

        } catch (Exception e) {
            log.error("Could not call MHealth services at this time  {\n }", e.getMessage());
            throw new InvalidInput("Could not call MHealth services at this time ");
        }
        return null;
    }

    @Override
    public String processAdherenceNotification(List<WebHookAdherenceRequest> requests, int type) throws InvalidInput {
        return adherenceMsg(requests, type);
    }

    private String adherenceMsg(List<WebHookAdherenceRequest> requests, int type) {
        String xmlNewTest = "";

        List<Adherence> adherenceList = new ArrayList<>();
        try {
        GviSmsMessageSbsCustom.RecipientList recipientList = new GviSmsMessageSbsCustom.RecipientList();

        for (WebHookAdherenceRequest userMessage : requests) {
            ADHERENCE_MSG = userMessage.getText() + " " + userMessage.getStartDate() + " - " + userMessage.getEndDate() + "?  Please answer with 1 or 2 \n" +
                    "1- YES\n" +
                    "2-NO";



            adherenceList.add(Adherence.builder()
                    .msisdn(userMessage.getPhone())
                    .text(userMessage.getText())
                    .userId(userMessage.getId())
                    .startDate(userMessage.getStartDate())
                    .messageStatus(MessageStatus.DISPATCHED)
                    .endDate(userMessage.getEndDate())
                    .adherencePayloadJson(JsonUtil.serializeObject(userMessage))
                    .type(type)
                    .build());
        }

        adherenceRepository.saveAll(adherenceList);
        List<AdherenceHistory> adherenceHistories = new ArrayList<>();
        adherenceList.forEach(
                adherence -> {
                    adherenceHistories.add(adherence.getAdherenceHistory());
                }
        );

        adherenceHistoryRepository.saveAll(adherenceHistories);

            requests.forEach(
                    webHookAdherenceRequest -> {
                        recipientList.getRecipient().add(GviSmsMessageSbsCustom.RecipientList.Recipient
                                .builder()
                                .msisdn(webHookAdherenceRequest.getPhone())
                                .message(webHookAdherenceRequest.getText())
                                .build());

                    }
            );

            GviSmsMessageSbsCustom gviSmsMessageSbsCustom = new GviSmsMessageSbsCustom();
            gviSmsMessageSbsCustom.setAffiliateCode(grapevineSmsProperties.getAffiliateCode());
            gviSmsMessageSbsCustom.setAuthenticationCode(grapevineSmsProperties.getAuthenticationCode());
            gviSmsMessageSbsCustom.setMessageType("Text");
//        gviSmsMessageSbsCustom.setSubmitDateTime(submitDateTime); //"2021-03-06T19:18:30"
            gviSmsMessageSbsCustom.setRecipientList(recipientList);


            JAXBContext jaxbContext = JAXBContext.newInstance(GviSmsMessageSbsCustom.class);
            Marshaller jaxbMarshaller = jaxbContext.createMarshaller();
            NamespacePrefixMapper mapper = new NamespacePrefixMapper() {
                public String getPreferredPrefix(String namespaceUri, String suggestion, boolean requirePrefix) {
                    return "";
                }
            };
            jaxbMarshaller.setProperty("com.sun.xml.bind.namespacePrefixMapper", mapper);
            jaxbMarshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, Boolean.TRUE);

            StringWriter sw = new StringWriter();
            jaxbMarshaller.marshal(gviSmsMessageSbsCustom, sw);
            xmlNewTest = sw.toString();
            xmlNewTest = xmlNewTest.replace(" xmlns=\"http://tempuri.org/xsd\"", ""); // FIXME find the correct to remove namespaces

            Upload upload = new Upload();
            upload.setXmlString(new ObjectFactory().createUploadXmlString(xmlNewTest));
            UploadResponse uploadResponse = (UploadResponse) soapConnector.callWebService(grapevineSmsProperties.getHostUrl(), upload);

            log.info("SMS Sent  to Adherent Participant  << {} >>", uploadResponse.toString());
            return uploadResponse.getReturn().getValue();
        } catch (JAXBException | JsonProcessingException e) {
            log.info("could not send sms ", e);
            return null;
        }

    }

    private void sendSms(String submitDateTime, String transmissionDate, String message, List<String> msisdns) {
        Upload upload = new Upload();
        upload.setXmlString(userSms(submitDateTime, transmissionDate, message, msisdns));
        UploadResponse uploadResponse = (UploadResponse) soapConnector.callWebService(grapevineSmsProperties.getHostUrl(), upload);

        log.info("SMS Sent to Survey Participant  << {} >>", uploadResponse.toString());
    }

    private JAXBElement<String> userSms(String submitDateTime, String transmissionDate, String message, List<String> msisdns) {

        String xmlNewTest = "";
        try {

            GviSmsMessageSbsCustom gviSmsMessageSbsCustom = new GviSmsMessageSbsCustom();
            gviSmsMessageSbsCustom.setAffiliateCode(grapevineSmsProperties.getAffiliateCode());
            gviSmsMessageSbsCustom.setAuthenticationCode(grapevineSmsProperties.getAuthenticationCode());
            gviSmsMessageSbsCustom.setMessageType("Text");
            gviSmsMessageSbsCustom.setSubmitDateTime(submitDateTime); //"2021-03-06T19:18:30"


            GviSmsMessageSbsCustom.TransmissionRules transmissionRules = new GviSmsMessageSbsCustom.TransmissionRules();
            transmissionRules.setTransmitDateTime(transmissionDate); //"2021-03-06T19:18:30"

            GviSmsMessageSbsCustom.TransmissionRules.TransmitPeriod transmitPeriod = new GviSmsMessageSbsCustom.TransmissionRules.TransmitPeriod();
            transmitPeriod.setEndHour(HOUR);
            transmitPeriod.setStartHour(HOUR);

            transmissionRules.setTransmitPeriod(transmitPeriod);
            gviSmsMessageSbsCustom.setTransmissionRules(transmissionRules);

            GviSmsMessageSbsCustom.RecipientList recipientList = new GviSmsMessageSbsCustom.RecipientList();
            recipientList.setMessage(message);
            msisdns.forEach(
                    s -> recipientList.getRecipient().add(GviSmsMessageSbsCustom.RecipientList.Recipient.builder().msisdn(s).build())
            );
            gviSmsMessageSbsCustom.setRecipientList(recipientList);


            JAXBContext jaxbContext = JAXBContext.newInstance(GviSmsMessageSbsCustom.class);
            Marshaller jaxbMarshaller = jaxbContext.createMarshaller();
            NamespacePrefixMapper mapper = new NamespacePrefixMapper() {
                public String getPreferredPrefix(String namespaceUri, String suggestion, boolean requirePrefix) {
                    return "";
                }
            };
            jaxbMarshaller.setProperty("com.sun.xml.bind.namespacePrefixMapper", mapper);
            jaxbMarshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, Boolean.TRUE);

            StringWriter sw = new StringWriter();
            jaxbMarshaller.marshal(gviSmsMessageSbsCustom, sw);
            xmlNewTest = sw.toString();
            xmlNewTest = xmlNewTest.replace(" xmlns=\"http://tempuri.org/xsd\"", ""); // FIXME find the correct to remove namespaces
        } catch (JAXBException e) {
            e.printStackTrace();
        }

        return new ObjectFactory().createUploadXmlString(xmlNewTest);
    }
}
