package com.sbs.zuatech.mhealth.api.dto;

import lombok.*;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
@ToString(doNotUseGetters = true)
public class USSDAppRequestEnd extends USSDAppRequest {
    private String reason;
}
